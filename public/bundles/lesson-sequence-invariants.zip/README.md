# 容器的第一课，是不变量。

从 vector 的失效规则，走到有界环形队列。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 实现固定容量环形队列

实现 IntRing(capacity)，push(int) 返回是否成功，pop() 返回 optional<int>，size() 返回当前元素数。

- 满时 push 失败且不覆盖旧数据；空时 pop 返回 nullopt。
- 容量 0 合法，所有 push 均失败；操作目标复杂度 O(1)。

### 实现可绕回的日志窗口 · 综合实现

实现 BoundedLog 的完整接口并论证复杂度，再设计泛型槽位扩展。

- 实现 BoundedLog(capacity)、push(int)、pop()、snapshot()、size()。
- 满时 push 返回 false 且不改状态；空 pop 返回 nullopt；snapshot 按 FIFO 返回副本。
- 测试容量为 0 至 1024，元素为 int；单线程使用。

## 工程验收

- [ ] 顺序出队正确
- [ ] 满时不覆盖
- [ ] 零容量无模零
- [ ] 绕回十轮仍保持顺序
- [ ] 综合测试通过
- [ ] 说明 snapshot 为线性复制且有独立寿命

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
