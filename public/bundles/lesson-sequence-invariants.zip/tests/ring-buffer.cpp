#include <sstream>
#include "fixture.hpp"
#include <optional>
#include "solutions/ring-buffer.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="8 9 0";IntRing q(2);q.push(8);q.push(9);std::cout<<*q.pop()<<" "<<*q.pop()<<" "<<q.size();break;}
case 1:{expected="0 2 4";IntRing q(2);q.push(1);q.push(2);std::cout<<q.push(3)<<" ";q.pop();q.push(4);std::cout<<*q.pop()<<" "<<*q.pop();break;}
case 2:{expected="000";IntRing q(0),r(1);std::cout<<q.push(1)<<q.pop().has_value()<<r.pop().has_value();break;}
case 3:{expected="1 0";IntRing q(7);bool ok=true;for(int n=0;n<1000;++n){ok&=q.push(n);auto v=q.pop();ok&=v&&*v==n;}std::cout<<ok<<" "<<q.size();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
