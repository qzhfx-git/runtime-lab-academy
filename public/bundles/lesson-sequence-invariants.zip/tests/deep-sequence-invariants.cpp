#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-sequence-invariants.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="110 1 2 0";BoundedLog q(2);std::cout<<q.push(1)<<q.push(2)<<q.push(3)<<" ";auto a=q.pop(),b=q.pop();std::cout<<a.value_or(-1)<<" "<<b.value_or(-1)<<" "<<q.size();break;}
case 1:{expected="3 4 5";BoundedLog q(3);for(int i=1;i<=3;++i)q.push(i);q.pop();q.pop();q.push(4);q.push(5);for(int x:q.snapshot())std::cout<<x<<" ";break;}
case 2:{expected="00 01 9";BoundedLog z(0);BoundedLog q(1);std::cout<<z.push(7)<<z.pop().has_value()<<" ";q.push(8);q.pop();std::cout<<q.pop().has_value()<<q.push(9)<<" "<<q.snapshot().at(0);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
