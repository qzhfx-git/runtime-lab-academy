#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class BoundedLog {
    std::vector<int> cells_;
    std::size_t head_ = 0, size_ = 0;
public:
    explicit BoundedLog(std::size_t capacity) : cells_(capacity) {}
    bool push(int value) {
        if (size_ == cells_.size()) return false;
        auto tail = (head_ + size_) % cells_.size();
        cells_[tail] = value;
        ++size_;
        return true;
    }
    std::optional<int> pop() {
        if (!size_) return std::nullopt;
        int value = cells_[head_];
        head_ = (head_ + 1) % cells_.size();
        --size_;
        return value;
    }
    std::vector<int> snapshot() const {
        std::vector<int> out;
        out.reserve(size_);
        for (std::size_t i=0; i<size_; ++i)
            out.push_back(cells_[(head_+i)%cells_.size()]);
        return out;
    }
    std::size_t size() const noexcept { return size_; }
};
int main() {
    BoundedLog q(3);
    bool a=q.push(10), b=q.push(20), c=q.push(30);
    assert(a && b && c);
    bool overflow=q.push(99);
    assert(!overflow);
    auto first=q.pop();
    assert(first==10);
    bool wrapped=q.push(40);
    assert(wrapped && (q.snapshot()==std::vector<int>{20,30,40}));
    for (int x:q.snapshot()) std::cout<<x<<' ';
    std::cout<<'\n';
}