class IntRing { public: explicit IntRing(std::size_t){} bool push(int){return false;} std::optional<int> pop(){return {};} std::size_t size()const{return 0;} };
