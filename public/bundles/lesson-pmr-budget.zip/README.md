# 把分配策略，提升为可观察的资源。

pmr、上游资源、生命周期与内存预算。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### TinyRuntime 前置实验：线性 Arena

实现 Arena::allocate 和 reset，在固定 256 字节存储里按顺序分配。容量不足返回 nullptr，并保持原分配位置。

- bytes > 0；alignment 为非零 2 的幂，不超过 alignof(max_align_t)。
- 成功分配的区域对齐且不重叠。
- reset 只回收空间，调用方负责此前对象的析构。

### 可计量的硬预算资源 · 综合实现

完成 BudgetResource 并验证 pmr 容器生命周期。

- 实现 BudgetResource(limit,upstream=new_delete_resource())，派生 memory_resource，提供 current/peak/allocations。
- 预算不足抛 bad_alloc；上游失败不更新计数；释放满足标准配对前置条件；空上游抛 invalid_argument。
- current 是未归还请求字节，peak 是历史最大值，allocations 是成功次数；单线程且总计数不超 size_t。

## 工程验收

- [ ] 申请释放配对
- [ ] 不销毁借用的上游
- [ ] 失败不计数
- [ ] 归还正确下降
- [ ] 综合测试通过
- [ ] 明确单线程限制

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
