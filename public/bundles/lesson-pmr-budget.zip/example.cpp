#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class BudgetResource final : public std::pmr::memory_resource {
    std::size_t limit_,current_=0,peak_=0,allocations_=0;
    std::pmr::memory_resource* upstream_;
protected:
    void* do_allocate(std::size_t bytes,std::size_t alignment) override {
        if (bytes>limit_-current_) throw std::bad_alloc();
        void* p=upstream_->allocate(bytes,alignment);
        current_+=bytes; peak_=std::max(peak_,current_); ++allocations_;
        return p;
    }
    void do_deallocate(void* p,std::size_t bytes,std::size_t alignment) override {
        upstream_->deallocate(p,bytes,alignment);
        current_-=bytes;
    }
    bool do_is_equal(const std::pmr::memory_resource& other) const noexcept override { return this==&other; }
public:
    explicit BudgetResource(std::size_t limit,std::pmr::memory_resource* upstream=std::pmr::new_delete_resource())
        :limit_(limit),upstream_(upstream) { if (!upstream) throw std::invalid_argument("null upstream"); }
    std::size_t current() const noexcept { return current_; }
    std::size_t peak() const noexcept { return peak_; }
    std::size_t allocations() const noexcept { return allocations_; }
};
int main(){BudgetResource resource(64);{std::pmr::vector<int> values(&resource);values.reserve(4);values.push_back(7);assert(resource.current()==values.capacity()*sizeof(int));auto before=resource.current();try{resource.allocate(1000,8);assert(false);}catch(const std::bad_alloc&){}assert(resource.current()==before);}assert(resource.current()==0&&resource.peak()>0&&resource.allocations()==1);std::cout<<"budget accounting ok\n";}