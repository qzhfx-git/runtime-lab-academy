#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-pmr-budget.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="24 24 2 0";BudgetResource r(32);void*p=r.allocate(8,8);void*q=r.allocate(16,8);std::cout<<r.current()<<" "<<r.peak()<<" "<<r.allocations()<<" ";r.deallocate(p,8,8);r.deallocate(q,16,8);std::cout<<r.current();break;}
case 1:{expected="11 8 0";BudgetResource r(8);void*p=r.allocate(8,8);bool b=false;try{r.allocate(1,1);}catch(const std::bad_alloc&){b=true;}BudgetResource no(8,std::pmr::null_memory_resource());bool u=false;try{no.allocate(1,1);}catch(const std::bad_alloc&){u=true;}std::cout<<b<<u<<" "<<r.current()<<" "<<no.allocations();r.deallocate(p,8,8);break;}
case 2:{expected="1 0 1";BudgetResource r(256);{std::pmr::vector<int> v(&r);v.reserve(8);std::cout<<(r.current()==v.capacity()*sizeof(int))<<" ";}std::cout<<r.current()<<" "<<(r.peak()>0);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
