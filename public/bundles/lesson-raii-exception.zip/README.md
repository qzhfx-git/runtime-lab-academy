# 每条退出路径，都有人负责。

RAII 与唯一资源责任。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 把清理动作绑定到作用域

实现 ScopeExit：构造接收 std::function<void()>；析构时执行一次；dismiss() 放弃执行；支持移动构造，禁止复制。回调约定不抛异常。

- 移动后旧对象不得再执行回调。
- 异常离开作用域也必须清理；不要求移动赋值。

### 可移动的预留额度事务

实现 DebitGuard(int& balance,int amount)：构造扣减额度，未 commit 时析构回滚，移动构造转移唯一回滚责任。

- amount 非负且不超过 balance，否则构造抛 invalid_argument 且余额不变。
- commit() 幂等；回滚与提交均不得发生两次。
- 禁止复制，不要求移动赋值；移动后的旧对象不再回滚。
- balance 必须比 guard 活得久；guard 活跃期间不得通过其他路径修改余额。本课单线程。

## 工程验收

- [ ] 早退也归还额度
- [ ] 参数无效不修改余额
- [ ] 移动来源不再回滚
- [ ] 栈展开不传播清理异常
- [ ] 全部测试通过
- [ ] 明确无法回滚的外部操作

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
