#include <sstream>
#include "fixture.hpp"
#include <utility>
#include <stdexcept>
#include "solutions/deep-raii-exception.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 10 6";int n=10;{DebitGuard a(n,3);std::cout<<n<<" ";}std::cout<<n<<" ";{DebitGuard b(n,4);b.commit();b.commit();}std::cout<<n;break;}
case 1:{expected="20";int n=20;try{DebitGuard a(n,8);throw std::runtime_error("abort");}catch(const std::runtime_error&){}std::cout<<n;break;}
case 2:{expected="10 0";int n=10;{DebitGuard a(n,6);DebitGuard b(std::move(a));}std::cout<<n<<" "<<std::is_copy_constructible_v<DebitGuard>;break;}
case 3:{expected="3 2";int n=3;int errors=0;try{DebitGuard a(n,4);}catch(const std::invalid_argument&){++errors;}try{DebitGuard b(n,-1);}catch(const std::invalid_argument&){++errors;}std::cout<<n<<" "<<errors;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
