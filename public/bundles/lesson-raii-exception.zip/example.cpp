#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <utility>
#include <stdexcept>
class DebitGuard {
    int* balance_;
    int amount_;
public:
    DebitGuard(int&balance,int amount):balance_(nullptr),amount_(amount){
        if(amount<0 || amount>balance)throw std::invalid_argument("budget");
        balance-=amount;
        balance_=&balance;
    }
    DebitGuard(const DebitGuard&)=delete;
    DebitGuard& operator=(const DebitGuard&)=delete;
    DebitGuard(DebitGuard&&other)noexcept
        :balance_(std::exchange(other.balance_,nullptr)),amount_(other.amount_){}
    ~DebitGuard()noexcept{if(balance_)*balance_+=amount_;}
    void commit()noexcept{balance_=nullptr;}
};
int main() {
int balance=20;
try{DebitGuard pending(balance,7);assert(balance==13);throw std::runtime_error("reject");}catch(const std::runtime_error&){}
assert(balance==20);
{DebitGuard first(balance,5);DebitGuard owner(std::move(first));assert(balance==15);}
assert(balance==20);
{DebitGuard success(balance,6);success.commit();}
assert(balance==14);std::cout<<balance<<' '<<std::is_copy_constructible_v<DebitGuard>;
}
