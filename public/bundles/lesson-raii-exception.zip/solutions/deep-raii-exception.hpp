class DebitGuard{public:DebitGuard(int&,int){}DebitGuard(const DebitGuard&)=delete;DebitGuard(DebitGuard&&)noexcept{}void commit()noexcept{}};
