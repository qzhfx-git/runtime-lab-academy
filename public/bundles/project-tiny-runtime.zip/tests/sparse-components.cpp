#include <sstream>
#include "fixture.hpp"
#include <optional>
#include "solutions/sparse-components.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="20 1";ComponentStore s;s.set(7,10);s.set(7,20);std::cout<<s.get(7).value_or(-1)<<" "<<s.ids().size();break;}
case 1:{expected="90 0 2";ComponentStore s;s.set(1,10);s.set(5,50);s.set(9,90);s.erase(5);std::cout<<s.get(9).value_or(-1)<<" "<<s.get(5).has_value()<<" "<<s.ids().size();break;}
case 2:{expected="10 8";ComponentStore s;s.set(1,2);std::cout<<s.erase(1)<<s.erase(1)<<" ";s.set(1,8);std::cout<<s.get(1).value_or(-1);break;}
case 3:{expected="1000";ComponentStore s;std::cout<<s.set(4095,3)<<s.set(4096,4)<<s.get(999999).has_value()<<s.erase(999999);break;}
case 4:{expected="1";ComponentStore s;for(unsigned i=0;i<100;++i)s.set(i,int(i*2));for(unsigned i=0;i<100;i+=2)s.erase(i);bool ok=s.ids().size()==50;for(auto id:s.ids())ok&=(id%2==1&&s.get(id)==int(id*2));std::cout<<ok;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
