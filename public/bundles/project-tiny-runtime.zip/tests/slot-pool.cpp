#include <sstream>
#include "fixture.hpp"
#include <optional>
#include "solutions/slot-pool.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 1 0 2";SlotPool p(2);std::cout<<p.acquire().value_or(99)<<" "<<p.acquire().value_or(99)<<" "<<p.acquire().has_value()<<" "<<p.used();break;}
case 1:{expected="0 2";SlotPool p(3);p.acquire();p.acquire();p.release(0);std::cout<<p.acquire().value_or(99)<<" "<<p.used();break;}
case 2:{expected="100 0";SlotPool p(1);p.acquire();std::cout<<p.release(0)<<p.release(0)<<p.release(9)<<" "<<p.used();break;}
case 3:{expected="000";SlotPool p(0);std::cout<<p.acquire().has_value()<<p.release(0)<<p.used();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
