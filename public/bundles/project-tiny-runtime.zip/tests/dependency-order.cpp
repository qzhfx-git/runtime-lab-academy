#include <sstream>
#include "fixture.hpp"
#include <optional>
#include <queue>
#include <functional>
#include "solutions/dependency-order.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 1 2 3";auto r=dependency_order(4,{{0,2},{1,2},{2,3}});if(r)for(int i:*r)std::cout<<i<<" ";break;}
case 1:{expected="00";std::cout<<dependency_order(2,{{0,1},{1,0}}).has_value()<<dependency_order(1,{{0,0}}).has_value();break;}
case 2:{expected="1 0 012";auto a=dependency_order(0,{});std::cout<<a.has_value()<<" "<<a->size()<<" ";auto independent=dependency_order(3,{});for(int i:*independent)std::cout<<i;break;}
case 3:{expected="012";auto r=dependency_order(3,{{0,1},{0,1},{1,2}});if(r)for(int i:*r)std::cout<<i;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
