#include <sstream>
#include "fixture.hpp"
#include <atomic>
#include <optional>
#include <thread>
#include "solutions/spsc-queue.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="110 7 8";SpscQueue q(2);std::cout<<q.try_push(7)<<q.try_push(8)<<q.try_push(9)<<" "<<q.try_pop().value_or(-1)<<" "<<q.try_pop().value_or(-1);break;}
case 1:{expected="00";SpscQueue q(0);std::cout<<q.try_push(1)<<q.try_pop().has_value();break;}
case 2:{expected="1 0";SpscQueue q(17);bool ok=true;std::thread p([&]{for(int i=0;i<5000;++i)while(!q.try_push(i))std::this_thread::yield();});for(int i=0;i<5000;++i){std::optional<int>v;while(!(v=q.try_pop()))std::this_thread::yield();ok&=*v==i;}p.join();std::cout<<ok<<" "<<q.try_pop().has_value();break;}
case 3:{expected="1";SpscQueue q(1);bool ok=true;for(int i=0;i<300;++i){ok&=q.try_push(i);auto v=q.try_pop();ok&=v&&*v==i;}std::cout<<ok;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
