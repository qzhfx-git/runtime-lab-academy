class SlotPool{public:explicit SlotPool(std::size_t){}std::optional<std::size_t> acquire(){return {};}bool release(std::size_t){return false;}std::size_t used()const{return 0;} };
