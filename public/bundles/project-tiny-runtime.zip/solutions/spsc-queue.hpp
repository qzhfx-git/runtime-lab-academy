class SpscQueue{public:explicit SpscQueue(std::size_t){}bool try_push(int){return false;}std::optional<int> try_pop(){return {};} };
