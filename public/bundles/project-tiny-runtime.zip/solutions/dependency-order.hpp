std::optional<std::vector<int>> dependency_order(int n,const std::vector<std::pair<int,int>>& edges){(void)n;(void)edges;return std::nullopt;}
