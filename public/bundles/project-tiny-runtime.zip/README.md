# TinyRuntime 组件底座

本项目包包含可分别构建和测试的组件模块。整合任务：将 ComponentStore、Arena 和任务执行层组织成多文件运行时，增加带代数的 Entity 句柄及访问声明。整合架构和性能结论需要人工评审，单题 AC 不代表系统已经生产可用。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### TinyRuntime 前置实验：线性 Arena

实现 Arena::allocate 和 reset，在固定 256 字节存储里按顺序分配。容量不足返回 nullptr，并保持原分配位置。

- bytes > 0；alignment 为非零 2 的幂，不超过 alignof(max_align_t)。
- 成功分配的区域对齐且不重叠。
- reset 只回收空间，调用方负责此前对象的析构。

### 管理可重复利用的固定槽位

实现 SlotPool(capacity)：acquire()->optional<size_t>，release(index)->bool，used()->size_t。空闲槽按后进先出复用，首次依次返回 0,1,2…

- 释放无效索引或重复释放必须返回 false 且不改变状态。
- 本题管理槽位编号，槽位中的对象构造与析构由上层负责。

### 实现紧凑的组件存储

实现 ComponentStore：set(entity,value)->bool、erase(entity)->bool、get(entity)->optional<int>、ids()->const vector<unsigned>&。实体 ID 为 0..4095。

- set 更新已有值，否则追加稠密数组；越界 ID 返回 false。
- erase 用尾元素覆盖被删除位置，并更新被移动实体的稀疏索引；不保证遍历顺序。
- ids 返回的引用在后续修改中可能失效。目标查找与删除 O(1)。

### 为构建任务生成依赖顺序

实现 dependency_order(n,edges)，边 (u,v) 表示 u 必须在 v 之前完成。返回 optional<vector<int>>；有环时 nullopt。多个就绪任务总是选编号最小者。

- 输入端点均在 [0,n)，n 非负；重复边按独立边计数。
- 空图返回有值的空数组；自环必须识别。

### 按数据流组织一帧更新

实现 step_positions(x,y,vx,vy,dt)：x/y 可写 vector<double>，vx/vy 为 const vector<double>&，每项位置加速度乘 dt。四个数组长度必须一致。

- 长度不一致时抛 invalid_argument，且不能修改任何位置。
- 空数组合法；dt 可以为 0 或负值；本题不做浮点误差敏感比较。

### 构建单生产者单消费者通道

实现 SpscQueue(capacity)：try_push(int)->bool，try_pop()->optional<int>。限定一个生产者和一个消费者，可同时操作。

- 满时 push 返回 false，空时 pop 返回 nullopt；容量 0 合法。
- 不覆盖尚未读取元素；槽位实际容量应等于构造参数。
- 本题不要求 is_lock_free() 为真；不得宣传该算法可用于多生产者。

## 工程验收

- [ ] 区分槽位生命周期、对象生命周期与实体身份，说明陈旧句柄检测
- [ ] 说明 swap erase 后稀疏/稠密索引为什么仍一致
- [ ] 定义系统读写集、依赖关系以及环和任务失败的处理
- [ ] 报告 AoS/SoA 的实验方法和数据，并记录同步及回收的未决风险

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
