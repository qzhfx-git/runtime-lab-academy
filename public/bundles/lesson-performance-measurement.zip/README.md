# 测量的是问题，不是一个漂亮数字。

建立 profiling、基准和复杂度的证据链。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 可复核的性能样本摘要

实现 summarize，返回数量、最小、上中位、最近秩 p99、最大值。

- 输入为非负 long long；空列表或负值抛 invalid_argument。
- 上中位下标 n/2，p99 排名 ceil(0.99*n)，排名从一开始。
- 不改变调用者列表；不测运行速度。

## 工程验收

- [ ] 区分排名和下标
- [ ] 解释小样本分位局限
- [ ] 错误输入明确拒绝
- [ ] 不改变调用者原始列表
- [ ] 计时边界一致
- [ ] 结论不超出负载证据

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
