#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-performance-measurement.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="5 1 4 9 9";auto s=summarize({9,1,4,4,2});std::cout<<s.count<<" "<<s.minimum<<" "<<s.median<<" "<<s.p99<<" "<<s.maximum;break;}
case 1:{expected="51 99 100";std::vector<long long>v;for(int i=100;i>=1;--i)v.push_back(i);auto s=summarize(v);std::cout<<s.median<<" "<<s.p99<<" "<<v.front();break;}
case 2:{expected="2";int n=0;try{summarize({});}catch(const std::invalid_argument&){++n;}try{summarize({1,-1});}catch(const std::invalid_argument&){++n;}std::cout<<n;break;}
case 3:{expected="1 0 0 0 0";auto s=summarize({0});std::cout<<s.count<<" "<<s.minimum<<" "<<s.median<<" "<<s.p99<<" "<<s.maximum;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
