struct SampleSummary {std::size_t count;long long minimum,median,p99,maximum;};
SampleSummary summarize(std::vector<long long>){return {0,0,0,0,0};}
