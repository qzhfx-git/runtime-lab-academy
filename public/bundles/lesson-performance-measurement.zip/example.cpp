#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

struct SampleSummary {
    std::size_t count;
    long long minimum, median, p99, maximum;
};
SampleSummary summarize(std::vector<long long> samples) {
    if(samples.empty()) throw std::invalid_argument("empty samples");
    for(auto value:samples)
        if(value<0) throw std::invalid_argument("negative duration");
    std::sort(samples.begin(),samples.end());
    auto n=samples.size();
    auto rank99=n-n/100;
    return {n,samples.front(),samples[n/2],samples[rank99-1],samples.back()};
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    std::vector<long long> values;
    for(int i=1;i<=100;++i) values.push_back(i);
    auto result=summarize(values);
    check_example(result.count==100 && result.minimum==1 && result.median==51);
    check_example(result.p99==99 && result.maximum==100);
    std::cout<<result.count<<' '<<result.minimum<<' '<<result.median
             <<' '<<result.p99<<' '<<result.maximum<<'\n';
}
