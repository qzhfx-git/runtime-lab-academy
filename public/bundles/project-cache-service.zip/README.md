# 可预测的缓存组件

交付一个固定容量、平均 O(1) 查询与更新的整数缓存。追加设计任务：如果容量改为字节预算，你会如何计算键值与索引成本？如果需要线程安全，锁应覆盖哪些操作？

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 实现固定容量环形队列

实现 IntRing(capacity)，push(int) 返回是否成功，pop() 返回 optional<int>，size() 返回当前元素数。

- 满时 push 失败且不覆盖旧数据；空时 pop 返回 nullopt。
- 容量 0 合法，所有 push 均失败；操作目标复杂度 O(1)。

### 维护优先任务的最小堆

实现 MinHeap::push(int)、pop()->optional<int> 和 size()。pop 每次取最小值，重复值保留。

- 空堆返回 nullopt。
- push/pop 的目标复杂度为 O(log n)；允许使用标准堆算法。

### 做一个可解释的 LRU 缓存

实现 LruCache(capacity)，put(key,value)，get(key)->optional<int>，size()。访问与更新都把键变为最近使用。

- 容量满时淘汰最久未使用项；容量 0 不保存内容。
- get 未命中不改变顺序；目标平均 O(1)；禁止复制以避免索引迭代器指向旧容器。

## 工程验收

- [ ] 用不变量解释命中、更新和淘汰后两个容器保持一致
- [ ] 说明 get/put 的平均与最坏复杂度，不把一次计时当成证明
- [ ] 审查迭代器生命周期、复制策略与分配失败的回滚
- [ ] 新增 TTL 或内存预算需求，并解释 API 和测试如何改变

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
