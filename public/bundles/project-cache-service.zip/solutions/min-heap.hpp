class MinHeap { public:void push(int){}std::optional<int> pop(){return {};}std::size_t size()const{return 0;} };
