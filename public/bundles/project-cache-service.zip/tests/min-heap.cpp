#include <sstream>
#include "fixture.hpp"
#include <optional>
#include <functional>
#include "solutions/min-heap.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 3 5";MinHeap h;for(int n:{5,1,3})h.push(n);while(auto n=h.pop())std::cout<<*n<<" ";break;}
case 1:{expected="-2 -2 0 7";MinHeap h;for(int n:{0,-2,-2,7})h.push(n);while(auto n=h.pop())std::cout<<*n<<" ";break;}
case 2:{expected="1 1 6 0";MinHeap h;h.push(4);h.push(6);h.pop();h.push(1);std::cout<<*h.pop()<<" "<<h.size()<<" "<<*h.pop()<<" "<<h.pop().has_value();break;}
case 3:{expected="1";MinHeap h;for(int i=499;i>=0;--i)h.push(i);bool ok=true;for(int i=0;i<500;++i){auto n=h.pop();ok&=n&&*n==i;}std::cout<<ok;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
