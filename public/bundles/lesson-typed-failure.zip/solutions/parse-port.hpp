std::optional<unsigned> parse_port(std::string_view text) { (void)text; return std::nullopt; }
