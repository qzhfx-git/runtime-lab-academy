#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <variant>
#include <string_view>
#include <charconv>
struct Limits{unsigned low,high;};
enum class LimitError{Empty,Syntax,Range,Order};
using LimitResult=std::variant<Limits,LimitError>;
LimitResult parse_limits(std::string_view text){
    if(text.empty())return LimitError::Empty;
    const auto colon=text.find(':');
    if(colon==text.npos || text.find(':',colon+1)!=text.npos)return LimitError::Syntax;
    auto number=[](std::string_view part)->std::variant<unsigned,LimitError>{
        if(part.empty())return LimitError::Syntax;
        for(char c:part)if(c<'0'||c>'9')return LimitError::Syntax;
        unsigned value=0;
        auto[end,error]=std::from_chars(part.data(),part.data()+part.size(),value);
        if(error!=std::errc{} || end!=part.data()+part.size() || value>1000000)return LimitError::Range;
        return value;
    };
    auto left=number(text.substr(0,colon));
    if(auto*error=std::get_if<LimitError>(&left))return *error;
    auto right=number(text.substr(colon+1));
    if(auto*error=std::get_if<LimitError>(&right))return *error;
    Limits result{std::get<unsigned>(left),std::get<unsigned>(right)};
    if(result.low>result.high)return LimitError::Order;
    return result;
}
int main() {
auto good=parse_limits("0002:10");assert(std::holds_alternative<Limits>(good));
auto value=std::get<Limits>(good);assert(value.low==2 && value.high==10);
assert(std::get<LimitError>(parse_limits("2:10x"))==LimitError::Syntax);
assert(std::get<LimitError>(parse_limits("1000001:2000000"))==LimitError::Range);
assert(std::get<LimitError>(parse_limits("10:2"))==LimitError::Order);
std::cout<<value.low<<' '<<value.high<<' '<<int(std::get<LimitError>(parse_limits("")));
}
