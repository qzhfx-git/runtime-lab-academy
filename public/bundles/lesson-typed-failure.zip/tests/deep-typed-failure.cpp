#include <sstream>
#include "fixture.hpp"
#include <variant>
#include <string_view>
#include <charconv>
struct Limits{unsigned low,high;};
enum class LimitError{Empty,Syntax,Range,Order};
using LimitResult=std::variant<Limits,LimitError>;
#include "solutions/deep-typed-failure.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 1000000 7";auto a=std::get<Limits>(parse_limits("000:1000000"));auto b=std::get<Limits>(parse_limits("7:7"));std::cout<<a.low<<" "<<a.high<<" "<<b.high;break;}
case 1:{expected="0 1 1 1 1 1";for(auto s:{"",":2","1:","1:2:3","+1:2","1:2x"})std::cout<<int(std::get<LimitError>(parse_limits(s)))<<" ";break;}
case 2:{expected="2 2 3";for(auto s:{"1000001:1000002","999999999999999999999:2","9:2"})std::cout<<int(std::get<LimitError>(parse_limits(s)))<<" ";break;}
case 3:{expected="1 2";std::cout<<int(std::get<LimitError>(parse_limits("99999999999999999x:2")))<<" "<<int(std::get<LimitError>(parse_limits("1000001:x")));break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
