#include <sstream>
#include "fixture.hpp"
#include <optional>
#include <string_view>
#include <charconv>
#include "solutions/parse-port.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="8080";std::cout<<parse_port("8080").value_or(0);break;}
case 1:{expected="0 1 65535 0";for(auto s:{"0","1","65535","65536"})std::cout<<parse_port(s).value_or(0)<<" ";break;}
case 2:{expected="000000";for(auto s:{""," 80","+80","-80","80x","80 "})std::cout<<parse_port(s).has_value();break;}
case 3:{expected="0 80";std::cout<<parse_port("99999999999999999").has_value()<<" "<<parse_port("00080").value_or(0);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
