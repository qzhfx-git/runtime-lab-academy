# 一个生产者，一个消费者。

从槽位所有权推导 SPSC 队列。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 构建单生产者单消费者通道

实现 SpscQueue(capacity)：try_push(int)->bool，try_pop()->optional<int>。限定一个生产者和一个消费者，可同时操作。

- 满时 push 返回 false，空时 pop 返回 nullopt；容量 0 合法。
- 不覆盖尚未读取元素；槽位实际容量应等于构造参数。
- 本题不要求 is_lock_free() 为真；不得宣传该算法可用于多生产者。

### 支持批量读取的 SPSC 队列

实现四个物理槽位、有效容量三的 BatchQueue。

- 一个生产者和一个消费者，析构不与访问重叠。
- push 满时返回 false，不覆盖未读值。
- pop_up_to 每批最多 min(limit,3) 项，零上限无副作用，非瞬时快照。
- 分配失败应在消费前发生，消费过程中不再扩容。

## 工程验收

- [ ] 说明四槽为何容量三
- [ ] 解释归还与发布的区别
- [ ] 先进先出不丢不重
- [ ] 失败写入和零读取不改变内容
- [ ] 销毁时无活动访问
- [ ] 不把压力测试当作同步证明

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
