#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class BatchQueue {
    std::array<int, 4> slots_{};
    std::atomic<std::size_t> head_{0}, tail_{0};
public:
    bool push(int value) {
        auto tail = tail_.load(std::memory_order_relaxed);
        auto next = (tail + 1) % slots_.size();
        if (next == head_.load(std::memory_order_acquire)) return false;
        slots_[tail] = value;
        tail_.store(next, std::memory_order_release);
        return true;
    }
    std::vector<int> pop_up_to(std::size_t limit) {
        std::vector<int> result;
        const auto batch = std::min(limit, slots_.size() - 1);
        result.reserve(batch);
        auto head = head_.load(std::memory_order_relaxed);
        while (result.size() < batch) {
            auto tail = tail_.load(std::memory_order_acquire);
            if (head == tail) break;
            result.push_back(slots_[head]);
            head = (head + 1) % slots_.size();
            head_.store(head, std::memory_order_release);
        }
        return result;
    }
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    BatchQueue queue;
    check_example(queue.push(10) && queue.push(20) && queue.push(30));
    check_example(!queue.push(40));
    auto first = queue.pop_up_to(2);
    check_example((first == std::vector<int>{10, 20}));
    check_example(queue.push(40) && queue.push(50));
    auto second = queue.pop_up_to(9);
    check_example((second == std::vector<int>{30, 40, 50}));
    for (int v : first) std::cout << v << ' ';
    for (std::size_t i=0; i<second.size(); ++i)
        std::cout << second[i] << (i+1==second.size()?'\n':' ');
}
