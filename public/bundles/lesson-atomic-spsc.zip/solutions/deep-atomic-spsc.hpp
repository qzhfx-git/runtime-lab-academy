class BatchQueue {
public:
    bool push(int) { return false; }
    std::vector<int> pop_up_to(std::size_t) { return {}; }
};
