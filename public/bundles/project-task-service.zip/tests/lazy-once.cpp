#include <sstream>
#include "fixture.hpp"
#include <functional>
#include <mutex>
#include <thread>
#include <atomic>
#include "solutions/lazy-once.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 7 1";int n=0;LazyInt x([&]{++n;return 7;});std::cout<<x.get()<<" "<<x.get()<<" "<<n;break;}
case 1:{expected="1 8 2";int n=0;LazyInt x([&]{if(++n==1)throw std::runtime_error("retry");return 8;});bool caught=false;try{x.get();}catch(...){caught=true;}std::cout<<caught<<" "<<x.get()<<" "<<n;break;}
case 2:{expected="1 104";std::atomic<int> calls{0},sum{0};LazyInt x([&]{++calls;return 13;});std::vector<std::thread>ts;for(int i=0;i<8;++i)ts.emplace_back([&]{sum+=x.get();});for(auto&t:ts)t.join();std::cout<<calls<<" "<<sum;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
