class LazyInt{public:explicit LazyInt(std::function<int()> f){(void)f;}int get(){return 0;} };
