# 可关闭的任务执行器

交付可排空关闭的任务执行器，线程数量由构造参数决定。扩展任务：增加有界待执行队列和显式取消模型，说明提交返回 rejected、cancelled、exception 的区别。Windows 本机评测没有运行 TSan。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 给共享状态定义同步边界

实现 ConcurrentCounter：add(long long) 和 value() const 必须可并发调用，初始值为 0。

- 所有访问同一个受保护的状态，不得使用 volatile 充当同步。
- 对象销毁前所有调用方已退出；数值不会溢出 long long。

### 让有界队列正确等待和关闭

实现 BlockingQueue(capacity)：push(int)->bool 队满等待，pop()->optional<int> 队空等待，close() 唤醒全部等待者。容量 0 抛 invalid_argument。

- close 后 push 返回 false；pop 排空已有元素后返回 nullopt。
- close 幂等；禁止忙等或依赖 sleep；对象销毁前调用方已退出。

### 交付可关闭的任务执行器

实现 TaskExecutor(workers)：submit(std::function<int()>)->future<int>；shutdown() 排空已接受任务后 join；析构自动关闭。

- 至少一个工作线程，否则抛 invalid_argument。关闭后提交抛 runtime_error。
- 任务异常通过 future.get() 传回调用方；不能导致工作线程退出。
- shutdown 只由拥有者线程调用，不能由任务调用；调用 submit 的线程必须在析构前结束。

### 并发初始化与失败重试

实现 LazyInt(factory)：get() 在第一次成功调用时缓存 factory() 的结果，并发调用只发生一次成功初始化。

- factory 抛异常时本次 get 传播异常，后续调用允许重试。
- 返回类型 int；对象寿命覆盖所有调用，不支持重置。

## 工程验收

- [ ] 画出接受任务、关闭与工作线程退出的线性化点
- [ ] 证明持锁期间不执行用户回调、不在锁内 join
- [ ] 说明任务丢失、重复执行、取消和异常传播的契约
- [ ] 用目标平台工具检查竞争，记录命令与限制，不用压力测试替代证明

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
