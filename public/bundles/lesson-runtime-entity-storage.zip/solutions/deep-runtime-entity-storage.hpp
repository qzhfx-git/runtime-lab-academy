struct EntityKey {
    std::size_t slot;std::uint32_t generation;
    friend bool operator==(const EntityKey&,const EntityKey&)=default;
};
class EntityTable {
public:
    EntityKey create(){return {0,0};}
    bool contains(EntityKey)const{return false;}
    bool erase(EntityKey){return false;}
    std::size_t live()const{return 0;}
};
