#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

struct EntityKey {
    std::size_t slot;
    std::uint32_t generation;
    friend bool operator==(const EntityKey&,const EntityKey&)=default;
};
class EntityTable {
    struct Slot {std::uint32_t generation=1;bool alive=false;bool retired=false;};
    std::vector<Slot> slots_;
    std::size_t live_=0;
public:
    EntityKey create() {
        for(std::size_t i=0;i<slots_.size();++i)
            if(!slots_[i].alive && !slots_[i].retired) {
                slots_[i].alive=true;++live_;
                return {i,slots_[i].generation};
            }
        slots_.push_back(Slot{1,true,false});++live_;
        return {slots_.size()-1,1};
    }
    bool contains(EntityKey key)const {
        return key.slot<slots_.size() && slots_[key.slot].alive &&
               slots_[key.slot].generation==key.generation;
    }
    bool erase(EntityKey key) {
        if(!contains(key)) return false;
        auto& slot=slots_[key.slot];
        slot.alive=false;--live_;
        if(slot.generation==std::numeric_limits<std::uint32_t>::max())
            slot.retired=true;
        else ++slot.generation;
        return true;
    }
    std::size_t live()const{return live_;}
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    EntityTable table;
    auto old=table.create();
    auto other=table.create();
    check_example(table.live()==2 && table.contains(old));
    check_example(table.erase(old));
    auto replacement=table.create();
    check_example(replacement.slot==old.slot);
    check_example(replacement.generation!=old.generation);
    check_example(!table.contains(old) && table.contains(other));
    check_example(table.contains(replacement) && table.live()==2);
    std::cout<<old.slot<<':'<<old.generation<<' '
             <<replacement.slot<<':'<<replacement.generation<<' '
             <<table.live()<<'\n';
}
