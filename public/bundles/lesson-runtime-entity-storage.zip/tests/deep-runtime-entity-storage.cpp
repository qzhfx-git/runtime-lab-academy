#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-runtime-entity-storage.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 1 1 2 11";EntityTable t;auto a=t.create(),b=t.create();std::cout<<a.slot<<" "<<b.slot<<" "<<a.generation<<" "<<t.live()<<" "<<t.contains(a)<<t.contains(b);break;}
case 1:{expected="1 1 2 01";EntityTable t;auto a=t.create();t.erase(a);auto b=t.create();std::cout<<(a.slot==b.slot)<<" "<<a.generation<<" "<<b.generation<<" "<<t.contains(a)<<t.contains(b);break;}
case 2:{expected="100 0";EntityTable t;auto a=t.create();std::cout<<t.erase(a)<<t.erase(a)<<t.erase({99,1})<<" "<<t.live();break;}
case 3:{expected="0 1 2";EntityTable t;auto a=t.create(),b=t.create(),c=t.create();t.erase(c);t.erase(a);auto d=t.create();std::cout<<d.slot<<" "<<t.contains(b)<<" "<<t.live();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
