# 实体身份，不能只是一处地址。

把 ECS 存储、代际句柄和对象生命接起来。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 实现紧凑的组件存储

实现 ComponentStore：set(entity,value)->bool、erase(entity)->bool、get(entity)->optional<int>、ids()->const vector<unsigned>&。实体 ID 为 0..4095。

- set 更新已有值，否则追加稠密数组；越界 ID 返回 false。
- erase 用尾元素覆盖被删除位置，并更新被移动实体的稀疏索引；不保证遍历顺序。
- ids 返回的引用在后续修改中可能失效。目标查找与删除 O(1)。

### 代际实体身份表

实现 EntityTable，生成 EntityKey 并管理存活身份。

- 新槽初始代际一，复用最低索引的可用空闲槽。
- 删除合法句柄后代际增加；达到 uint32 最大代际的槽删除后退役。
- contains 同时检查范围、存活和代际；非法或重复删除返回 false。
- live 返回活跃数；接口仅顺序使用，不提供组件或并发回收。

## 工程验收

- [ ] 死亡身份不通过
- [ ] 扩容不改变身份含义
- [ ] 活跃计数守恒
- [ ] 代际上限策略明确
- [ ] 移动后映射一致
- [ ] 不把 contains 当并发保活

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
