# 让别人能够重建你的证据。

从单文件通过走向可重复构建与测试。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 严格运行时配置解析

实现 parse_config，解析固定格式 workers=N;capacity=M。

- 字段顺序固定，不接受空白、正负号、额外分号或尾随内容。
- workers 范围 1..64，capacity 范围 1..1000000。
- 合法返回 RuntimeConfig；其他情况返回 nullopt。
- 不得读取外部环境或执行启动副作用。

## 工程验收

- [ ] 失败无半有效配置
- [ ] 不在解析函数中启动线程
- [ ] 尾随垃圾被拒绝
- [ ] 溢出不截断
- [ ] 明确 C++20 要求
- [ ] Release 下测试检查仍有效

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
