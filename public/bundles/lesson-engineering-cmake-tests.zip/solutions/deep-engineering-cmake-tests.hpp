struct RuntimeConfig {
    unsigned workers,capacity;
    friend bool operator==(const RuntimeConfig&,const RuntimeConfig&)=default;
};
std::optional<RuntimeConfig> parse_config(std::string_view){return std::nullopt;}
