#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

struct RuntimeConfig {
    unsigned workers,capacity;
    friend bool operator==(const RuntimeConfig&,const RuntimeConfig&)=default;
};
std::optional<RuntimeConfig> parse_config(std::string_view input) {
    if(!input.starts_with("workers=")) return std::nullopt;
    input.remove_prefix(8);
    auto split=input.find(';');
    if(split==std::string_view::npos) return std::nullopt;
    auto first=input.substr(0,split);
    auto second=input.substr(split+1);
    if(!second.starts_with("capacity=")) return std::nullopt;
    second.remove_prefix(9);
    auto number=[](std::string_view s)->std::optional<unsigned>{
        if(s.empty()) return std::nullopt;
        unsigned value=0;
        auto result=std::from_chars(s.data(),s.data()+s.size(),value);
        if(result.ec!=std::errc{} || result.ptr!=s.data()+s.size()) return std::nullopt;
        return value;
    };
    auto workers=number(first),capacity=number(second);
    if(!workers || !capacity || *workers<1 || *workers>64 ||
       *capacity<1 || *capacity>1000000) return std::nullopt;
    return RuntimeConfig{*workers,*capacity};
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    auto good=parse_config("workers=4;capacity=256");
    check_example(good && good->workers==4 && good->capacity==256);
    check_example(!parse_config("workers=4;capacity=256junk"));
    check_example(!parse_config("workers=0;capacity=256"));
    std::cout<<good->workers<<' '<<good->capacity<<'\n';
}
