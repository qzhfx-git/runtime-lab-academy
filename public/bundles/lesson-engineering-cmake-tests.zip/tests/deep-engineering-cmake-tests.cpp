#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-engineering-cmake-tests.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 1 1000000";auto a=parse_config("workers=1;capacity=1"),b=parse_config("workers=64;capacity=1000000");std::cout<<bool(a)<<" "<<bool(b)<<" "<<(b?b->capacity:0);break;}
case 1:{expected="000";std::cout<<bool(parse_config("workers=4;capacity=20x"))<<bool(parse_config("workers=+4;capacity=20"))<<bool(parse_config("workers=4;capacity=20 "));break;}
case 2:{expected="000";std::cout<<bool(parse_config("workers=0;capacity=1"))<<bool(parse_config("workers=65;capacity=1"))<<bool(parse_config("workers=4;capacity=9999999999999999999999"));break;}
case 3:{expected="000";std::cout<<bool(parse_config("capacity=2;workers=1"))<<bool(parse_config("workers=;capacity=2"))<<bool(parse_config("workers=2;capacity=3;"));break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
