# 可组合的事件系统

实现具有确定派发语义的单线程事件分发器。扩展任务：设计不可复制的 Subscription RAII 句柄。注意发布者可能先于订阅者析构，不能只在句柄中保存裸 EventBus*。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 让订阅与退订拥有确定语义

实现 EventBus：subscribe(function<void(int)>)->int 返回唯一 ID；unsubscribe(id)->bool；publish(value) 按注册顺序调用快照里的订阅者。

- 发布时先复制本轮回调快照；回调内新增、删除订阅只影响后续发布。
- 未知 ID 退订返回 false；本题单线程，不支持回调内递归 publish；回调异常直接传播。

### 组合可替换的处理策略

实现 TextPipeline：add(function<string(string)>) 添加步骤，run(string) 按注册顺序执行；空管线返回原文。

- 管线拥有回调；用户输入按值传入，不修改调用方字符串。
- 异常向调用方传播，不悄悄返回成功。

### 把清理动作绑定到作用域

实现 ScopeExit：构造接收 std::function<void()>；析构时执行一次；dismiss() 放弃执行；支持移动构造，禁止复制。回调约定不抛异常。

- 移动后旧对象不得再执行回调。
- 异常离开作用域也必须清理；不要求移动赋值。

## 工程验收

- [ ] 说明快照派发中新增与退订的时序，避免隐含承诺
- [ ] 证明捕获对象不会因延迟回调而悬空
- [ ] 定义回调异常、中途取消和递归调用的策略
- [ ] 比较 std::function、虚接口、CRTP 的扩展与分配成本

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
