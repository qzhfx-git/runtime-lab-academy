#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <memory>
#include <utility>
#include <stdexcept>
template<class T> class ObjectSlot {
    alignas(T) std::byte storage_[sizeof(T)];
    T* live_ = nullptr;
public:
    ObjectSlot() = default;
    ObjectSlot(const ObjectSlot&) = delete;
    ObjectSlot& operator=(const ObjectSlot&) = delete;
    ~ObjectSlot() { reset(); }
    template<class... A> T& emplace(A&&... args) {
        if (live_) throw std::logic_error("occupied");
        T* next = std::construct_at(reinterpret_cast<T*>(storage_),
                                    std::forward<A>(args)...);
        live_ = next;
        return *live_;
    }
    T& value() { if (!live_) throw std::logic_error("empty"); return *live_; }
    bool has_value() const noexcept { return live_ != nullptr; }
    void reset() noexcept {
        if (live_) { std::destroy_at(live_); live_ = nullptr; }
    }
};
int main() {
int destroyed=0;
struct Task { int value; int* counter; Task(int v,int&c):value(v),counter(&c){if(v<0)throw std::runtime_error("bad");} ~Task(){++*counter;} };
ObjectSlot<Task> slot;
try { slot.emplace(-1,destroyed); } catch(const std::runtime_error&) {}
assert(!slot.has_value() && destroyed==0);
slot.emplace(7,destroyed);
assert(slot.value().value==7);
slot.reset(); slot.reset();
assert(destroyed==1);
slot.emplace(9,destroyed);
std::cout<<slot.value().value<<' '<<destroyed<<' '<<slot.has_value();
}
