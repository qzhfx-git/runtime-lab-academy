# 有内存，不等于有对象。

分开观察分配、构造、析构与回收。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 空间准备好了，对象呢？

实现 create_widget 与 destroy_widget：在调用方提供的原始空间上构造 Widget；销毁时只结束对象生命周期，不释放调用方的空间。

- storage 大小、对齐均满足 Widget 的要求。
- Widget 由题目提供，包含 value 和静态 alive 计数。
- destroy_widget 接收存活对象。

### 可恢复的单对象槽位

实现 ObjectSlot<T>：在预留原始存储里最多容纳一个 T，对构造失败、重复构造和销毁保持明确状态。

- emplace(args...) 返回 T&；非空时抛 logic_error，原对象不变。
- 构造失败后保持空槽；value() 在空槽上抛 logic_error。
- reset() 幂等，成功构造的对象恰好析构一次；T 的析构不抛出。
- 槽位不可复制、不可移动，避免内部对象被当作字节搬运。

## 工程验收

- [ ] 空槽读取抛异常
- [ ] 成功构造的值可以读取
- [ ] 失败不产生完整对象析构
- [ ] 重复 reset 不增加计数
- [ ] 全部综合测试通过
- [ ] 禁止复制移动且无原始字节搬运

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
