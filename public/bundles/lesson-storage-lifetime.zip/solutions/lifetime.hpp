Widget* create_widget(void* storage, int value) {
    // TODO: 在给定位置构造
    return nullptr;
}
void destroy_widget(Widget* object) {
    // TODO: 只销毁，不释放存储
}

