#include <sstream>
#include "fixture.hpp"
#include <memory>
#include <utility>
#include <stdexcept>
#include "solutions/deep-storage-lifetime.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 1";ObjectSlot<int>s;s.emplace(7);try{s.emplace(9);}catch(const std::logic_error&){}std::cout<<s.value()<<" "<<s.has_value();break;}
case 1:{expected="0 5";struct P{int n;explicit P(int v):n(v){if(v<0)throw std::runtime_error("bad");}};ObjectSlot<P>s;try{s.emplace(-1);}catch(const std::runtime_error&){}std::cout<<s.has_value()<<" ";s.emplace(5);std::cout<<s.value().n;break;}
case 2:{expected="2 1";int dead=0;struct P{int* p;explicit P(int&d):p(&d){}~P(){++*p;}};{ObjectSlot<P>s;s.emplace(dead);s.reset();s.reset();s.emplace(dead);}bool caught=false;ObjectSlot<int>x;try{x.value();}catch(const std::logic_error&){caught=true;}std::cout<<dead<<" "<<caught;break;}
case 3:{expected="1 8";struct alignas(64)P{int x;explicit P(int n):x(n){}};ObjectSlot<P>s;auto&p=s.emplace(8);std::cout<<(reinterpret_cast<std::uintptr_t>(&p)%alignof(P)==0)<<" "<<p.x;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
