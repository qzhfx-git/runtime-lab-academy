#include <sstream>
#include "fixture.hpp"

#include "solutions/lifetime.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 42 1";alignas(Widget)std::byte mem[sizeof(Widget)];auto p=create_widget(mem,42);std::cout<<(static_cast<void*>(p)==mem)<<' '<<(p?p->value:-1)<<' '<<Widget::alive;if(p)destroy_widget(p);break;}
case 1:{expected="0 9 0";alignas(Widget)std::byte mem[sizeof(Widget)];auto p=create_widget(mem,7);if(p)destroy_widget(p);std::cout<<Widget::alive;auto q=create_widget(mem,9);std::cout<<' '<<(q?q->value:-1);if(q)destroy_widget(q);std::cout<<' '<<Widget::alive;break;}
case 2:{expected="2 -3 15";alignas(Widget)std::byte a[sizeof(Widget)],b[sizeof(Widget)];auto p=create_widget(a,-3);auto q=create_widget(b,15);std::cout<<Widget::alive<<' '<<(p?p->value:0)<<' '<<(q?q->value:0);if(p)destroy_widget(p);if(q)destroy_widget(q);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
