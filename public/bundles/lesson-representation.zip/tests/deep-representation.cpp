#include <sstream>
#include "fixture.hpp"
#include <array>
#include <span>
#include <optional>
#include <cstdint>
struct WireRecord{std::uint16_t id;std::uint32_t count;bool enabled;bool operator==(const WireRecord&)const=default;};
#include "solutions/deep-representation.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="18 52 1 2 3 4 1";auto b=encode_record({0x1234,0x01020304,true});for(auto x:b)std::cout<<unsigned(x)<<" ";break;}
case 1:{expected="1 0";WireRecord a{65535,4294967295u,false};auto b=encode_record(a);auto r=decode_record(b);std::cout<<(r&&*r==a)<<" "<<(r?r->enabled:false);break;}
case 2:{expected="000";std::array<std::uint8_t,7>b{};b[6]=2;std::cout<<decode_record(b).has_value()<<decode_record(std::span<const std::uint8_t>(b).first(6)).has_value()<<decode_record({}).has_value();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
