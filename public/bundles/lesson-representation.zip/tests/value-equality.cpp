#include <sstream>
#include "fixture.hpp"

#include "solutions/value-equality.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1";Record a{'x',true,2.5},b{'x',true,2.5};std::cout<<same_value(a,b);break;}
case 1:{expected="1";Record a{'x',true,0.0},b{'x',true,-0.0};std::cout<<same_value(a,b);break;}
case 2:{expected="0";Record a{'x',true,std::numeric_limits<double>::quiet_NaN()};std::cout<<same_value(a,a);break;}
case 3:{expected="000";Record a{'x',true,2.5};std::cout<<same_value(a,Record{'y',true,2.5})<<same_value(a,Record{'x',false,2.5})<<same_value(a,Record{'x',true,3.5});break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
