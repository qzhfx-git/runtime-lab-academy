std::array<std::uint8_t,7> encode_record(const WireRecord&){return {};}
std::optional<WireRecord> decode_record(std::span<const std::uint8_t>){return {};}
