struct Record { char id; bool active; double weight; };
bool same_value(const Record& a, const Record& b) {
    // TODO: 按字段比较
    return false;
}

