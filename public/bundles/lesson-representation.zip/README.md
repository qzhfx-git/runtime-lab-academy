# 比较的是值，还是字节？

把对象表示与语义、别名规则分开。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 比较值，而不是整块字节

实现 same_value，比较 Record 的 id、active、weight 是否相等。weight 按普通 double 的 == 语义比较。

- +0.0 与 -0.0 相等；NaN 与自身不相等。
- 结果不得依赖 padding 字节。

### 稳定的七字节记录格式

实现 encode_record 与 decode_record：明确字段、端序与布尔编码，不复制结构体原始表示。

- 格式恰好七字节：id 两字节大端，count 四字节大端，enabled 为 0 或 1。
- decode_record(span<const uint8_t>) 长度不是七或布尔字节非法时返回 nullopt。
- 所有字段边界值都必须无损往返，不依赖结构体填充或主机端序。

## 工程验收

- [ ] 相等关系不读取 padding
- [ ] 能区分表示与意义
- [ ] 输出恒为七字节
- [ ] 最大字段值保留
- [ ] 全部综合测试通过
- [ ] 失败不会暴露部分对象

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
