#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <array>
#include <span>
#include <optional>
#include <cstdint>
struct WireRecord{std::uint16_t id;std::uint32_t count;bool enabled;bool operator==(const WireRecord&)const=default;};
std::array<std::uint8_t,7> encode_record(const WireRecord&r){
    return {std::uint8_t(r.id>>8),std::uint8_t(r.id),
        std::uint8_t(r.count>>24),std::uint8_t(r.count>>16),
        std::uint8_t(r.count>>8),std::uint8_t(r.count),std::uint8_t(r.enabled?1:0)};
}
std::optional<WireRecord> decode_record(std::span<const std::uint8_t>b){
    if(b.size()!=7 || b[6]>1)return {};
    auto id=std::uint16_t((std::uint16_t(b[0])<<8)|b[1]);
    auto count=(std::uint32_t(b[2])<<24)|(std::uint32_t(b[3])<<16)
        |(std::uint32_t(b[4])<<8)|std::uint32_t(b[5]);
    return WireRecord{id,count,b[6]!=0};
}
int main() {
WireRecord input{0x1234,0x01020304,true};
auto bytes=encode_record(input);
assert(bytes[0]==18 && bytes[1]==52 && bytes[6]==1);
auto output=decode_record(bytes); assert(output && *output==input);
bytes[6]=9; assert(!decode_record(bytes));
std::cout<<output->id<<' '<<output->count<<' '<<output->enabled;
}
