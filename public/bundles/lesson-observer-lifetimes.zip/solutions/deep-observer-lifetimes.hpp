class Signal {public: class Connection {public: void disconnect() noexcept{}}; Connection connect(std::function<void(int)>){return {};} void emit(int){}};
