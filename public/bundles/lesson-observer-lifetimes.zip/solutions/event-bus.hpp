class EventBus{int next_=1;public:int subscribe(std::function<void(int)>){return next_++;}bool unsubscribe(int){return false;}void publish(int){} };
