#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class Signal {
    struct State { std::map<std::size_t,std::function<void(int)>> slots; std::size_t next=1; };
    std::shared_ptr<State> state_=std::make_shared<State>();
public:
    class Connection {
        std::weak_ptr<State> state_;
        std::size_t id_=0;
        friend class Signal;
        Connection(std::weak_ptr<State> state,std::size_t id):state_(std::move(state)),id_(id) {}
    public:
        Connection()=default;
        Connection(const Connection&)=delete;
        Connection& operator=(const Connection&)=delete;
        Connection(Connection&& other) noexcept :state_(std::move(other.state_)),id_(std::exchange(other.id_,0)) {}
        Connection& operator=(Connection&& other) noexcept {
            if (this!=&other) { disconnect(); state_=std::move(other.state_); id_=std::exchange(other.id_,0); }
            return *this;
        }
        void disconnect() noexcept {
            if (auto state=state_.lock()) state->slots.erase(id_);
            id_=0; state_.reset();
        }
        ~Connection() { disconnect(); }
    };
    Signal()=default;
    Signal(const Signal&)=delete;
    Signal& operator=(const Signal&)=delete;
    Connection connect(std::function<void(int)> fn) {
        if (!fn) throw std::invalid_argument("empty callback");
        if (state_->next==std::numeric_limits<std::size_t>::max()) throw std::overflow_error("ids exhausted");
        auto id=state_->next++;
        state_->slots.emplace(id,std::move(fn));
        return Connection(state_,id);
    }
    void emit(int value) {
        auto state=state_;
        std::vector<std::size_t> snapshot;
        for (const auto& [id,fn]:state->slots) { (void)fn; snapshot.push_back(id); }
        for (auto id:snapshot) {
            auto it=state->slots.find(id);
            if (it==state->slots.end()) continue;
            auto fn=it->second; // 回调可退订自身，局部副本负责本次调用的寿命
            fn(value);
        }
    }
};
int main(){Signal s;int total=0;auto a=s.connect([&](int n){total+=n;});{auto b=s.connect([&](int n){total+=10*n;});s.emit(2);assert(total==22);}s.emit(3);assert(total==25);auto moved=std::move(a);moved.disconnect();s.emit(99);assert(total==25);Signal::Connection detached;{Signal shortLived;detached=shortLived.connect([](int){});}detached.disconnect();std::cout<<"observer total=25\n";}