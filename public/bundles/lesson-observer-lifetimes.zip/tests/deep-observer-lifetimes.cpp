#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-observer-lifetimes.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="13";Signal s;int n=0;auto a=s.connect([&](int x){n+=x;});{auto b=s.connect([&](int x){n+=10*x;});s.emit(1);}auto moved=std::move(a);s.emit(2);moved.disconnect();s.emit(8);std::cout<<n;break;}
case 1:{expected="A";Signal s;std::string order;Signal::Connection b;auto a=s.connect([&](int){order+="A";b.disconnect();});b=s.connect([&](int){order+="B";});s.emit(0);std::cout<<order;break;}
case 2:{expected="0 10";Signal s;int n=0;bool added=false;std::vector<Signal::Connection> tokens;auto a=s.connect([&](int){if(!added){tokens.push_back(s.connect([&](int){n+=10;}));added=true;}});s.emit(0);std::cout<<n<<" ";s.emit(0);std::cout<<n;break;}
case 3:{expected="1";Signal::Connection c;bool threw=false;{Signal s;c=s.connect([](int){throw std::runtime_error("x");});try{s.emit(1);}catch(const std::runtime_error&){threw=true;}}c.disconnect();std::cout<<threw;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
