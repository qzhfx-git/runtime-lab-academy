#include <sstream>
#include "fixture.hpp"
#include <functional>
#include <map>
#include "solutions/event-bus.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="34";EventBus b;b.subscribe([](int v){std::cout<<v;});b.subscribe([](int v){std::cout<<v+1;});b.publish(3);break;}
case 1:{expected="10 0";EventBus b;int n=0;int id=b.subscribe([&](int){++n;});std::cout<<b.unsubscribe(id)<<b.unsubscribe(id)<<" ";b.publish(1);std::cout<<n;break;}
case 2:{expected="ABA";EventBus b;int second=0;b.subscribe([&](int){std::cout<<"A";b.unsubscribe(second);});second=b.subscribe([](int){std::cout<<"B";});b.publish(0);b.publish(0);break;}
case 3:{expected="AAB";EventBus b;bool added=false;b.subscribe([&](int){std::cout<<"A";if(!added){added=true;b.subscribe([](int){std::cout<<"B";});}});b.publish(0);b.publish(0);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
