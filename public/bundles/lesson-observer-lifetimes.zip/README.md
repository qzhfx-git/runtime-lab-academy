# 退订不是删掉一个回调那么简单。

把 Observer 的派发、寿命与取消语义写清楚。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 让订阅与退订拥有确定语义

实现 EventBus：subscribe(function<void(int)>)->int 返回唯一 ID；unsubscribe(id)->bool；publish(value) 按注册顺序调用快照里的订阅者。

- 发布时先复制本轮回调快照；回调内新增、删除订阅只影响后续发布。
- 未知 ID 退订返回 false；本题单线程，不支持回调内递归 publish；回调异常直接传播。

### 可安全退订的事件连接 · 综合实现

完成 Signal，写出单线程和接收者保活契约。

- 实现 Signal 与嵌套可移动、不可复制的 Connection；connect(function<void(int)>)->Connection、emit(int)、Connection::disconnect()。
- 连接析构退订；源先销毁安全；按注册顺序派发；本轮开始后新增延迟到下一轮，已退订项跳过。
- 单线程使用；复制回调到局部后调用；首次异常向上传播并终止本轮。空回调抛 invalid_argument；连接ID不回绕。

## 工程验收

- [ ] 退出作用域退订
- [ ] 源先销毁仍安全
- [ ] 已退订项跳过
- [ ] 新订阅下一轮生效
- [ ] 综合测试通过
- [ ] 不宣称退订能取消已开始调用

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
