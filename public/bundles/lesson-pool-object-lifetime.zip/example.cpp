#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
struct PoolRecord {
    inline static int alive=0;
    int value;
    explicit PoolRecord(int v):value(v) {
        if (v<0) throw std::runtime_error("construction failure");
        ++alive;
    }
    ~PoolRecord() noexcept { --alive; }
    PoolRecord(const PoolRecord&)=delete;
};
template<class T,std::size_t N> class SlotPool {
    static_assert(std::is_nothrow_destructible_v<T>);
    struct Slot {
        alignas(T) std::byte storage[sizeof(T)];
        T* object=nullptr;
        std::uint64_t generation=1;
        bool retired=false;
    };
    std::array<Slot,N> slots_{};
public:
    struct Handle { std::size_t index; std::uint64_t generation; };
    SlotPool()=default;
    SlotPool(const SlotPool&)=delete;
    SlotPool& operator=(const SlotPool&)=delete;
    template<class... Args> std::optional<Handle> emplace(Args&&... args) {
        for (std::size_t i=0;i<N;++i) {
            auto& s=slots_[i];
            if (s.object || s.retired) continue;
            T* p=std::construct_at(reinterpret_cast<T*>(s.storage),std::forward<Args>(args)...);
            s.object=p;
            return Handle{i,s.generation};
        }
        return std::nullopt;
    }
    T* get(Handle h) noexcept {
        if (h.index>=N) return nullptr;
        auto& s=slots_[h.index];
        return s.generation==h.generation ? s.object : nullptr;
    }
    bool erase(Handle h) noexcept {
        T* p=get(h);
        if (!p) return false;
        auto& s=slots_[h.index];
        std::destroy_at(p); s.object=nullptr;
        if (s.generation==std::numeric_limits<std::uint64_t>::max()) s.retired=true;
        else ++s.generation;
        return true;
    }
    ~SlotPool() { for (auto& s:slots_) if (s.object) std::destroy_at(s.object); }
};
int main() {
    {
        SlotPool<PoolRecord,1> pool;
        auto first=pool.emplace(7);
        assert(first && PoolRecord::alive==1);
        bool erased=pool.erase(*first);
        bool repeated=pool.erase(*first);
        assert(erased && !repeated);
        auto second=pool.emplace(9);
        assert(second && !pool.get(*first) && pool.get(*second)->value==9);
        try {
            SlotPool<PoolRecord,1> other;
            other.emplace(-1);
            assert(false);
        } catch (const std::runtime_error&) {}
        assert(PoolRecord::alive==1);
    }
    assert(PoolRecord::alive==0);
    std::cout<<"pool lifetime ok\n";
}