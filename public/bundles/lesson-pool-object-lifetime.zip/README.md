# 复用一个槽位，不是复用一个对象。

空闲表、构造异常与带代数的句柄。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 管理可重复利用的固定槽位

实现 SlotPool(capacity)：acquire()->optional<size_t>，release(index)->bool，used()->size_t。空闲槽按后进先出复用，首次依次返回 0,1,2…

- 释放无效索引或重复释放必须返回 false 且不改变状态。
- 本题管理槽位编号，槽位中的对象构造与析构由上层负责。

### 带代数句柄的对象池 · 综合实现

完成 SlotPool，设计空闲索引栈及回绕策略。

- 实现 template<class T,size_t N> SlotPool；Handle 含 index、generation；emplace 返回 optional<Handle>，get 返回 T*，erase 返回 bool。
- 构造异常向上传播且保持槽空闲；用尽返回 nullopt；析构全部活对象；T 的析构不抛出。
- 单线程、不复制池；只使用本池句柄；代数最大值后退休槽位。

## 工程验收

- [ ] 构造析构成对
- [ ] 退出清理剩余对象
- [ ] 失败后可重试
- [ ] 旧句柄无法命中新对象
- [ ] 综合测试通过
- [ ] 说明当前扫描为 O(N)

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
