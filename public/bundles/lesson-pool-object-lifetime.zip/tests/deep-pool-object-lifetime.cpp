#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
struct PoolRecord {
    inline static int alive=0;
    int value;
    explicit PoolRecord(int v):value(v) {
        if (v<0) throw std::runtime_error("construction failure");
        ++alive;
    }
    ~PoolRecord() noexcept { --alive; }
    PoolRecord(const PoolRecord&)=delete;
};

#include "solutions/deep-pool-object-lifetime.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="110 2 0";{SlotPool<PoolRecord,2> p;auto a=p.emplace(1);auto b=p.emplace(2);std::cout<<bool(a)<<bool(b)<<bool(p.emplace(3))<<" "<<PoolRecord::alive<<" ";}std::cout<<PoolRecord::alive;break;}
case 1:{expected="10 1 2";SlotPool<PoolRecord,1> p;auto a=p.emplace(1);if(!a){std::cout<<"missing";break;}std::cout<<p.erase(*a)<<p.erase(*a)<<" ";auto b=p.emplace(2);std::cout<<(p.get(*a)==nullptr)<<" "<<(b&&p.get(*b)?p.get(*b)->value:-1);break;}
case 2:{expected="1 1 1";SlotPool<PoolRecord,1> p;bool failed=false;try{p.emplace(-1);}catch(const std::runtime_error&){failed=true;}auto a=p.emplace(7);std::cout<<failed<<" "<<bool(a)<<" "<<PoolRecord::alive;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
