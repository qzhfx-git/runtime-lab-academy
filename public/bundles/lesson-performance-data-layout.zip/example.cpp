#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

bool step_selected(std::vector<float>& position,
                   const std::vector<float>& velocity,
                   const std::vector<std::size_t>& selected, float dt) {
    if (position.size()!=velocity.size()) return false;
    for (auto i:selected) if (i>=position.size()) return false;
    for (auto i:selected) position[i]+=velocity[i]*dt;
    return true;
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    std::vector<float> x{1,4,8}, v{2,-2,4};
    check_example(step_selected(x,v,{0,2},0.5f));
    check_example((x==std::vector<float>{2,4,10}));
    auto before=x;
    check_example(!step_selected(x,v,{1,9},1.0f));
    check_example(x==before);
    for(std::size_t i=0;i<x.size();++i)
        std::cout<<x[i]<<(i+1==x.size()?'\n':' ');
}
