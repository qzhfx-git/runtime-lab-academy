# 布局要跟着访问模式走。

把 AoS、SoA 与局部性放回具体工作负载。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 按数据流组织一帧更新

实现 step_positions(x,y,vx,vy,dt)：x/y 可写 vector<double>，vx/vy 为 const vector<double>&，每项位置加速度乘 dt。四个数组长度必须一致。

- 长度不一致时抛 invalid_argument，且不能修改任何位置。
- 空数组合法；dt 可以为 0 或负值；本题不做浮点误差敏感比较。

### 选中实体更新器

实现 step_selected，更新指定位置字段。

- 位置与速度为不同向量，输入数值有限。
- 长度不等或任何索引越界返回 false，位置完整保持。
- 合法请求按列表顺序逐项更新，重复索引重复应用。
- 只验证语义，不用时间阈值评价性能。

## 工程验收

- [ ] 说明索引如何关联实体
- [ ] 列出至少一个可能受损阶段
- [ ] 错误请求不修改位置
- [ ] 重复索引遵循约定
- [ ] 不使用时间阈值当功能判定
- [ ] 记录映射与维护成本

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
