bool step_selected(std::vector<float>&,const std::vector<float>&,
const std::vector<std::size_t>&,float){return false;}
