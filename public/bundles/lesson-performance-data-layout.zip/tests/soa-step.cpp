#include <sstream>
#include "fixture.hpp"

#include "solutions/soa-step.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="2 4 2 5";std::vector<double>x{1,2},y{3,4};step_positions(x,y,{2,4},{-2,2},0.5);std::cout<<x[0]<<" "<<x[1]<<" "<<y[0]<<" "<<y[1];break;}
case 1:{expected="1 1 3";std::vector<double>x{1,2},y{3};bool caught=false;try{step_positions(x,y,{1,1},{1,1},1);}catch(const std::invalid_argument&){caught=true;}std::cout<<caught<<" "<<x[0]<<" "<<y[0];break;}
case 2:{expected="1 1";std::vector<double>x,y;step_positions(x,y,{},{},1);x={2};y={3};step_positions(x,y,{1},{2},-1);std::cout<<x[0]<<" "<<y[0];break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
