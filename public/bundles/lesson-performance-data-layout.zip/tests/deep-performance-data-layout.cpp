#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-performance-data-layout.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 2 4 10";std::vector<float>x{1,4,8},v{2,-2,4};std::cout<<step_selected(x,v,{0,2},0.5f);for(auto n:x)std::cout<<" "<<n;break;}
case 1:{expected="0 1 2";std::vector<float>x{1,2},v{3,4};std::cout<<step_selected(x,v,{0,9},1);for(auto n:x)std::cout<<" "<<n;break;}
case 2:{expected="1 5 1";std::vector<float>x{1},v{2};std::cout<<step_selected(x,v,{0,0},1)<<" "<<x[0]<<" "<<step_selected(x,v,{},1);break;}
case 3:{expected="0 1";std::vector<float>x{1,2},v{3};std::cout<<step_selected(x,v,{0},1)<<" "<<x[0];break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
