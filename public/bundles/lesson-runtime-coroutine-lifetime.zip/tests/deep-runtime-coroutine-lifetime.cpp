#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-runtime-coroutine-lifetime.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="3 7 7 1 0";{std::vector<int>v{3,7};auto s=make_stream(v);v[0]=99;int x=-1;while(s.next(x))std::cout<<x<<" ";std::cout<<x<<" "<<IntStream::frames()<<" ";}std::cout<<IntStream::frames();break;}
case 1:{expected="0 8 1 0";std::stop_source stop;{auto s=make_stream({1,2},stop.get_token());int x=8;stop.request_stop();std::cout<<s.next(x)<<" "<<x<<" "<<IntStream::frames()<<" ";}std::cout<<IntStream::frames();break;}
case 2:{expected="1 4 error 0 4 0";{auto s=make_stream({4,5},{},1);int x=0;bool first=s.next(x);std::cout<<first<<" "<<x<<" ";try{s.next(x);}catch(const std::runtime_error&){std::cout<<"error ";}std::cout<<s.next(x)<<" "<<x<<" ";}std::cout<<IntStream::frames();break;}
case 3:{expected="2 1 0 1 2 0";{auto a=make_stream({2});auto b=make_stream({9});std::cout<<IntStream::frames()<<" ";b=std::move(a);int x=0;std::cout<<IntStream::frames()<<" "<<a.next(x)<<" "<<b.next(x)<<" "<<x<<" ";}std::cout<<IntStream::frames();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
