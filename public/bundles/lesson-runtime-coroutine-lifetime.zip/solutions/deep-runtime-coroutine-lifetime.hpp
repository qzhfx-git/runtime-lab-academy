class IntStream {
public:
    IntStream()=default;
    IntStream(const IntStream&)=delete;
    IntStream& operator=(const IntStream&)=delete;
    IntStream(IntStream&&)noexcept=default;
    IntStream& operator=(IntStream&&)noexcept=default;
    static int frames()noexcept{return 0;}
    bool next(int&){return false;}
};
IntStream make_stream(std::vector<int>,std::stop_token={},int=-1){return {};}
