# 挂起以后，谁还活着？

协程帧所有权、恢复与协作式取消。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 可取消的整数协程流

实现 IntStream 与 make_stream，按值持有输入并逐项产出。

- C++20 惰性启动，final_suspend 保留帧，由唯一返回对象析构销毁。
- 禁止复制，支持空对象、移动和覆盖移动；frames 返回存活 promise 数。
- next 仅产出时修改输出；完成返回 false；协程异常在该次 next 重抛。
- 每次产出前先检查停止，再检查 fail_at；非负 fail_at 对应位置抛 runtime_error。
- 仅顺序单线程使用，输入向量按值拥有；stop_token 按值保存。

### 交付可关闭的任务执行器

实现 TaskExecutor(workers)：submit(std::function<int()>)->future<int>；shutdown() 排空已接受任务后 join；析构自动关闭。

- 至少一个工作线程，否则抛 invalid_argument。关闭后提交抛 runtime_error。
- 任务异常通过 future.get() 传回调用方；不能导致工作线程退出。
- shutdown 只由拥有者线程调用，不能由任务调用；调用 submit 的线程必须在析构前结束。

## 工程验收

- [ ] 区分完成与释放
- [ ] 不恢复已完成句柄
- [ ] 输出仅产出时改变
- [ ] 所有拥有者退出后帧数归零
- [ ] 无恢复与销毁并发
- [ ] 普通阻塞等待有明确退出机制

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
