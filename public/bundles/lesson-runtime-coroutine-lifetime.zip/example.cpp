#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class IntStream {
public:
    struct promise_type;
    using Handle=std::coroutine_handle<promise_type>;
    struct promise_type {
        inline static int live=0;
        int value=0;
        std::exception_ptr error;
        promise_type()noexcept{++live;}
        ~promise_type(){--live;}
        IntStream get_return_object(){return IntStream(Handle::from_promise(*this));}
        std::suspend_always initial_suspend()noexcept{return {};}
        std::suspend_always final_suspend()noexcept{return {};}
        std::suspend_always yield_value(int n)noexcept{value=n;return {};}
        void return_void()noexcept{}
        void unhandled_exception()noexcept{error=std::current_exception();}
    };
private:
    Handle handle_{};
    explicit IntStream(Handle handle):handle_(handle){}
public:
    IntStream()=default;
    IntStream(const IntStream&)=delete;
    IntStream& operator=(const IntStream&)=delete;
    IntStream(IntStream&& other)noexcept:handle_(std::exchange(other.handle_,{})){}
    IntStream& operator=(IntStream&& other)noexcept {
        if(this!=&other){
            if(handle_)handle_.destroy();
            handle_=std::exchange(other.handle_,{});
        }
        return *this;
    }
    ~IntStream(){if(handle_)handle_.destroy();}
    static int frames()noexcept{return promise_type::live;}
    bool next(int& output) {
        if(!handle_ || handle_.done()) return false;
        handle_.resume();
        if(handle_.promise().error)std::rethrow_exception(handle_.promise().error);
        if(handle_.done())return false;
        output=handle_.promise().value;return true;
    }
};
IntStream make_stream(std::vector<int> values,std::stop_token stop={},int fail_at=-1) {
    for(std::size_t i=0;i<values.size();++i){
        if(stop.stop_requested())co_return;
        if(fail_at>=0 && i==static_cast<std::size_t>(fail_at))
            throw std::runtime_error("stream failure");
        co_yield values[i];
    }
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    check_example(IntStream::frames()==0);
    {
        std::stop_source stop;
        auto stream=make_stream({4,8},stop.get_token());
        check_example(IntStream::frames()==1);
        int value=-1;
        check_example(stream.next(value) && value==4);
        std::cout<<value<<' ';
        stop.request_stop();
        check_example(!stream.next(value) && value==4);
        check_example(IntStream::frames()==1);
        std::cout<<IntStream::frames()<<' ';
    }
    check_example(IntStream::frames()==0);
    std::cout<<IntStream::frames()<<'\n';
}
