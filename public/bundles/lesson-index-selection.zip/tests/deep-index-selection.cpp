#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-index-selection.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="aa ab";PrefixIndex x;for(auto s:{"ab","aa","b","aa"})x.insert(s);for(auto& s:x.top("a",5))std::cout<<s<<" ";break;}
case 1:{expected="10 render";PrefixIndex x;x.insert("render");x.insert("read");std::cout<<x.erase("read")<<x.erase("missing")<<" ";for(auto&s:x.top("re",1))std::cout<<s;break;}
case 2:{expected="0 0 2 0";PrefixIndex x;x.insert("");x.insert("b");std::cout<<x.top("",0).size()<<" "<<x.top("x",4).size()<<" "<<x.top("",9).size()<<" "<<x.insert("b");break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
