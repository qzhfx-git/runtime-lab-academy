#include <sstream>
#include "fixture.hpp"

#include "solutions/prefix-trie.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="101";CommandTrie t;t.insert("build");std::cout<<t.contains("build")<<t.contains("bui")<<t.starts_with("bui");break;}
case 1:{expected="1110";CommandTrie t;t.insert("run");t.insert("rust");t.insert("run");std::cout<<t.contains("run")<<t.contains("rust")<<t.starts_with("ru")<<t.contains("ruby");break;}
case 2:{expected="011";CommandTrie t;std::cout<<t.contains("")<<t.starts_with("");t.insert("");std::cout<<t.contains("");break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
