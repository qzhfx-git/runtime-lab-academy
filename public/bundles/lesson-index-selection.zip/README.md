# 先写访问模式，再选结构。

哈希、树、堆、Trie 各自回答不同的问题。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 为命令面板建立前缀索引

实现 CommandTrie::insert(string)、contains(string) 和 starts_with(string)。只考虑小写 ASCII 字母与空串。

- 前缀存在不代表完整单词已注册。
- 重复插入幂等，空前缀始终存在，空单词可显式插入。

### 构建动态前缀索引 · 综合实现

完成 PrefixIndex，并为 set、哈希扫描和 Trie 制定同语义比较。

- 实现 PrefixIndex::insert(string)、erase(string)、top(prefix,limit)。
- insert/erase 返回是否真正改变集合；top 返回去重后的字典序前 limit 个匹配键。
- 前缀按字节定义；空前缀匹配全部；单线程使用。

## 工程验收

- [ ] 返回顺序正确
- [ ] 重复键仅一次
- [ ] 不存在的键可安全删除
- [ ] 旧结果副本不受后续更新影响
- [ ] 综合测试通过
- [ ] 基准保持相同语义并记录分布

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
