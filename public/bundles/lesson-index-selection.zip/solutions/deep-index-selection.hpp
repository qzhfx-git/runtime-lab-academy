class PrefixIndex { public: bool insert(std::string){return false;} bool erase(const std::string&){return false;} std::vector<std::string> top(const std::string&,std::size_t) const{return {};} };
