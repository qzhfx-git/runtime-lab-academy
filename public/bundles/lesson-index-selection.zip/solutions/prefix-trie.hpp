class CommandTrie{public:void insert(const std::string&){}bool contains(const std::string&)const{return false;}bool starts_with(const std::string&)const{return false;} };
