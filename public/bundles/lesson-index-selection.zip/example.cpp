#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class PrefixIndex {
    std::set<std::string> keys_;
public:
    bool insert(std::string key) { return keys_.insert(std::move(key)).second; }
    bool erase(const std::string& key) { return keys_.erase(key) != 0; }
    std::vector<std::string> top(const std::string& prefix, std::size_t limit) const {
        std::vector<std::string> out;
        for (auto it=keys_.lower_bound(prefix); it!=keys_.end() && out.size()<limit; ++it) {
            if (!it->starts_with(prefix)) break;
            out.push_back(*it);
        }
        return out;
    }
};
int main() {
    PrefixIndex index;
    for (auto s:{"run","render","reset","read","run"}) index.insert(s);
    auto a=index.top("re",2);
    assert((a==std::vector<std::string>{"read","render"}));
    bool removed=index.erase("read");
    assert(removed && index.top("re",1).at(0)=="render");
    for (const auto& s:a) std::cout<<s<<' ';
    std::cout<<'\n';
}