#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

bool apply_adjustments(std::vector<int>& balances,
                       const std::vector<std::pair<std::size_t,int>>& changes) {
    for(int value:balances) if(value<0) return false;
    auto staged=balances;
    for(auto [index,delta]:changes) {
        if(index>=staged.size()) return false;
        auto next=static_cast<long long>(staged[index])+delta;
        if(next<0 || next>std::numeric_limits<int>::max()) return false;
        staged[index]=static_cast<int>(next);
    }
    balances.swap(staged);
    return true;
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    std::vector<int> balances{10,20};
    check_example(apply_adjustments(balances,{{0,-3},{1,3}}));
    check_example((balances==std::vector<int>{7,23}));
    auto before=balances;
    check_example(!apply_adjustments(balances,{{0,2},{1,-100}}));
    check_example(balances==before);
    std::cout<<balances[0]<<' '<<balances[1]<<'\n';
}
