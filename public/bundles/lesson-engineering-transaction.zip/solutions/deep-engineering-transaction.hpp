bool apply_adjustments(std::vector<int>&,
const std::vector<std::pair<std::size_t,int>>&){return false;}
