#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-engineering-transaction.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 7 23";std::vector<int>b{10,20};std::cout<<apply_adjustments(b,{{0,-3},{1,3}})<<" "<<b[0]<<" "<<b[1];break;}
case 1:{expected="0 10 20";std::vector<int>b{10,20};std::cout<<apply_adjustments(b,{{0,2},{9,1}})<<" "<<b[0]<<" "<<b[1];break;}
case 2:{expected="0 3";std::vector<int>b{3};std::cout<<apply_adjustments(b,{{0,-4},{0,4}})<<" "<<b[0];break;}
case 3:{expected="0 1 1";std::vector<int>b{std::numeric_limits<int>::max()};std::cout<<apply_adjustments(b,{{0,1}})<<" "<<(b[0]==std::numeric_limits<int>::max())<<" "<<apply_adjustments(b,{});break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
