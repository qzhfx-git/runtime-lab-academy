#include <sstream>
#include "fixture.hpp"
#include <map>
#include "solutions/transaction-update.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 3 2";std::map<std::string,int>m{{"a",1}};std::cout<<update_config(m,{{"b",2},{"a",3}})<<" "<<m.at("a")<<" "<<m.at("b");break;}
case 1:{expected="0 1 1";std::map<std::string,int>m{{"a",1}};std::cout<<update_config(m,{{"a",9},{"b",-1}})<<" "<<m.at("a")<<" "<<m.size();break;}
case 2:{expected="1 4 1";std::map<std::string,int>m;bool ok=update_config(m,{{"a",2},{"a",4}});std::cout<<ok<<" "<<m.at("a")<<" "<<update_config(m,{});break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
