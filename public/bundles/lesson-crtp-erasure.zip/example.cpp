#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <concepts>
#include <optional>
#include <limits>
struct SequenceSummary{std::size_t count;long long total;int minimum,maximum;};
template<class T>concept HasSummary=requires(const T&value){value.summarize();};
#include <stdexcept>
#include <algorithm>
template<class D>concept IntegerSequence=requires(const D&value,std::size_t index){
    {value.size()}->std::convertible_to<std::size_t>;
    {value.at(index)}->std::same_as<int>;
};
template<class D>class SequenceMixin {
    friend D;
    SequenceMixin()=default;
    SequenceMixin(const SequenceMixin&)=default;
protected:
    ~SequenceMixin()=default;
public:
    std::optional<SequenceSummary> summarize()const requires IntegerSequence<D>{
        const auto&self=static_cast<const D&>(*this);
        const auto count=static_cast<std::size_t>(self.size());
        if(count>1000000)throw std::length_error("sequence too large");
        if(count==0)return {};
        const int first=self.at(0);
        SequenceSummary result{count,first,first,first};
        for(std::size_t i=1;i<count;++i){const int n=self.at(i);result.total+=n;result.minimum=std::min(result.minimum,n);result.maximum=std::max(result.maximum,n);}
        return result;
    }
};
int main() {
class Samples final:public SequenceMixin<Samples>{
 std::vector<int> values_;
public:explicit Samples(std::vector<int>v):values_(std::move(v)){}
 std::size_t size()const{return values_.size();}
 int at(std::size_t i)const{return values_.at(i);}
};
struct Wrong:SequenceMixin<Samples>{};
static_assert(!std::is_default_constructible_v<Wrong>);
static_assert(!std::is_polymorphic_v<Samples>);
static_assert(HasSummary<Samples>);
const Samples samples({-2,5,8});auto direct=samples.summarize();
assert(direct&&direct->total==11&&direct->minimum==-2&&direct->maximum==8);
std::function<std::optional<SequenceSummary>()> erased=[&samples]{return samples.summarize();};
assert(erased()->total==direct->total);
const Samples empty({});assert(!empty.summarize());
std::cout<<direct->count<<' '<<direct->total<<' '<<erased()->maximum;
}
