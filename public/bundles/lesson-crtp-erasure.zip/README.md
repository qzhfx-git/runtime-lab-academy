# 抽象放在编译期，还是运行期？

CRTP、虚接口和类型擦除各自付出不同成本。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 用 CRTP 复用静态接口

实现 SumMixin<Derived>::sum() const。Derived 提供 size() const 与 at(size_t) const，基类把元素累加为 long long。

- 通过 static_cast<const Derived&>(*this) 调用派生接口。
- 不存储元素、不使用 virtual、不在基类构造函数中调用派生接口。

### 有静态契约的 CRTP 序列分析

实现 SequenceMixin<Derived>::summarize() const，为只读整数序列提供统计，并限制错误的基类构造。

- Derived 的 size() const 可转换为 size_t；at(size_t) const 必须精确返回 int。不满足时 summarize 不参与调用。
- 语义上 size 必须返回可无损转换为 size_t 的非负长度；同次统计中长度与元素读取保持一致。Concepts 不自动证明这项语义。
- 空序列返回 nullopt 且不调用 at；非空返回 count、long long total、minimum、maximum。
- size 大于 1000000 时抛 length_error，避免无界遍历并给累加范围提供上界；元素异常直接传播。
- 基类默认与复制构造为 private，仅 friend Derived；析构为 protected；不得使用 virtual。
- 不在基类构造或析构期间调用派生接口，实际对象必须与 CRTP 参数匹配。

## 工程验收

- [ ] 不使用 virtual
- [ ] 宽类型累加正确
- [ ] 错误返回类型不可调用
- [ ] 普通错误配对不可构造
- [ ] 全部综合测试通过
- [ ] 能解释异构集合为何另需统一表示

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
