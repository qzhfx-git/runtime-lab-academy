#include <sstream>
#include "fixture.hpp"
#include <concepts>
#include <optional>
#include <limits>
struct SequenceSummary{std::size_t count;long long total;int minimum,maximum;};
template<class T>concept HasSummary=requires(const T&value){value.summarize();};
#include <stdexcept>
#include <algorithm>
#include "solutions/deep-crtp-erasure.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="3 5 -4 7";struct S:SequenceMixin<S>{S()=default;std::size_t size()const{return 3;}int at(std::size_t i)const{return i==0?-4:(i==1?7:2);}};const S value;auto r=value.summarize();if(!r)std::cout<<"empty";else std::cout<<r->count<<" "<<r->total<<" "<<r->minimum<<" "<<r->maximum;break;}
case 1:{expected="0 1";struct Empty:SequenceMixin<Empty>{Empty()=default;std::size_t size()const{return 0;}int at(std::size_t)const{throw std::logic_error("unexpected");}};struct Huge:SequenceMixin<Huge>{Huge()=default;std::size_t size()const{return 1000001;}int at(std::size_t)const{return 1;}};bool caught=false;try{Huge{}.summarize();}catch(const std::length_error&){caught=true;}std::cout<<Empty{}.summarize().has_value()<<" "<<caught;break;}
case 2:{expected="0";struct Bad:SequenceMixin<Bad>{Bad()=default;std::size_t size()const{return 1;}double at(std::size_t)const{return 1;}};std::cout<<HasSummary<Bad>;break;}
case 3:{expected="000";struct Good:SequenceMixin<Good>{Good()=default;std::size_t size()const{return 1;}int at(std::size_t)const{return 1;}};struct Wrong:SequenceMixin<Good>{};std::cout<<std::is_default_constructible_v<SequenceMixin<Good>><<std::is_default_constructible_v<Wrong><<std::is_polymorphic_v<Good>;break;}
case 4:{expected="6000000000 1";struct S:SequenceMixin<S>{S()=default;std::size_t size()const{return 3;}int at(std::size_t)const{return 2000000000;}};struct Broken:SequenceMixin<Broken>{Broken()=default;std::size_t size()const{return 2;}int at(std::size_t i)const{if(i)throw std::runtime_error("failed");return 1;}};bool caught=false;try{Broken{}.summarize();}catch(const std::runtime_error&){caught=true;}auto summary=S{}.summarize();std::cout<<(summary?summary->total:0)<<" "<<caught;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
