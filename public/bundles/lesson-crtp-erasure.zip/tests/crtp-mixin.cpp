#include <sstream>
#include "fixture.hpp"

#include "solutions/crtp-mixin.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="6";struct A:SumMixin<A>{std::size_t size()const{return 3;} int at(std::size_t i)const{return int(i+1);}}; const A a;std::cout<<a.sum();break;}
case 1:{expected="0";struct A:SumMixin<A>{std::size_t size()const{return 0;}int at(std::size_t)const{throw std::logic_error("empty");}};std::cout<<A{}.sum();break;}
case 2:{expected="6000000000 0";struct A:SumMixin<A>{std::size_t size()const{return 3;}int at(std::size_t)const{return 2000000000;}};std::cout<<A{}.sum()<<" "<<std::is_polymorphic_v<SumMixin<A>>;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
