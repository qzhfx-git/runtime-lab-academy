template<class D>class SequenceMixin{public:SequenceMixin()=default;std::optional<SequenceSummary>summarize()const{return {};}};
