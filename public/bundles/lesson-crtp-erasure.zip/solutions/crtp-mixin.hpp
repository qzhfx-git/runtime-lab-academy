template<class Derived> struct SumMixin { long long sum() const { return 0; } };
