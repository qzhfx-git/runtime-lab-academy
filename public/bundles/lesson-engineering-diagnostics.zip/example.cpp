#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class CountLease {
    int* counter_=nullptr;
public:
    explicit CountLease(int& counter) {
        if(counter<0) throw std::invalid_argument("negative counter");
        if(counter==std::numeric_limits<int>::max())
            throw std::overflow_error("counter full");
        ++counter; counter_=&counter;
    }
    CountLease(const CountLease&)=delete;
    CountLease& operator=(const CountLease&)=delete;
    CountLease(CountLease&& other) noexcept
        :counter_(std::exchange(other.counter_,nullptr)){}
    CountLease& operator=(CountLease&& other) noexcept {
        if(this!=&other) {release();counter_=std::exchange(other.counter_,nullptr);}
        return *this;
    }
    ~CountLease() noexcept {release();}
    void release() noexcept {if(counter_){--*counter_;counter_=nullptr;}}
    bool active() const noexcept {return counter_!=nullptr;}
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    int first=0, second=0;
    {
        CountLease a(first),b(second);
        check_example(first==1 && second==1);
        b=std::move(a);
        check_example(!a.active() && b.active());
        check_example(first==1 && second==0);
        std::cout<<first<<' '<<second<<' ';
        b.release();
        b.release();
        check_example(first==0);
        std::cout<<first<<'\n';
    }
    check_example(first==0 && second==0);
}
