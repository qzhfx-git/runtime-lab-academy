class CountLease {
public:
    explicit CountLease(int&){}
    CountLease(const CountLease&)=delete;
    CountLease& operator=(const CountLease&)=delete;
    CountLease(CountLease&&)noexcept{}
    CountLease& operator=(CountLease&&)noexcept{return *this;}
    void release()noexcept{}
    bool active()const noexcept{return false;}
};
