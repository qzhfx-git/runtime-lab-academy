#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-engineering-diagnostics.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 01 0";int n=0;{CountLease a(n);CountLease b(std::move(a));std::cout<<n<<" "<<a.active()<<b.active()<<" ";b.release();b.release();}std::cout<<n;break;}
case 1:{expected="1 0 1 0 0";int a=0,b=0;{CountLease x(a),y(b);y=std::move(x);y=std::move(y);std::cout<<a<<" "<<b<<" "<<y.active()<<" ";}std::cout<<a<<" "<<b;break;}
case 2:{expected="0";int n=0;try{CountLease lease(n);throw std::runtime_error("test");}catch(const std::exception&){}std::cout<<n;break;}
case 3:{expected="2 1 -1";int n=std::numeric_limits<int>::max(),m=-1,c=0;try{CountLease a(n);}catch(const std::overflow_error&){++c;}try{CountLease b(m);}catch(const std::invalid_argument&){++c;}std::cout<<c<<" "<<(n==std::numeric_limits<int>::max())<<" "<<m;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
