class TransactionalLru { public: explicit TransactionalLru(std::size_t){} std::optional<int> get(int){return {};} void put(int,int,bool=false){} std::vector<int> keys() const{return {};} };
