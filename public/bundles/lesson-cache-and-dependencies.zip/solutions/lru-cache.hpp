class LruCache { public:explicit LruCache(std::size_t){} LruCache(const LruCache&)=delete;void put(int,int){}std::optional<int> get(int){return {};}std::size_t size()const{return 0;} };
