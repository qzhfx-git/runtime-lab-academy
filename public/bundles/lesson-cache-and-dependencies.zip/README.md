# 让数据结构，服务于系统模型。

LRU 的双结构一致性与 DAG 的依赖协议。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 做一个可解释的 LRU 缓存

实现 LruCache(capacity)，put(key,value)，get(key)->optional<int>，size()。访问与更新都把键变为最近使用。

- 容量满时淘汰最久未使用项；容量 0 不保存内容。
- get 未命中不改变顺序；目标平均 O(1)；禁止复制以避免索引迭代器指向旧容器。

### 带失败回滚的 LRU · 综合实现

提交 TransactionalLru，并为任务依赖图设计失败传播协议。

- 实现 TransactionalLru(capacity)、get(key)、put(key,value,injectFailure=false)、keys()。
- keys 按最新到最旧返回；故障开关仅对非零容量的新键生效，抛 runtime_error 且完全回滚。
- 整数键和值；不要求复制缓存；单线程使用。

## 工程验收

- [ ] 更新同键不增数量
- [ ] 命中改变淘汰顺序
- [ ] 异常后键集合不变
- [ ] 异常后新旧顺序不变
- [ ] 综合测试通过
- [ ] 区分环节点与受环阻塞节点

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
