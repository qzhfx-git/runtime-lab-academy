#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class TransactionalLru {
    using Entry = std::pair<int,int>;
    std::size_t capacity_;
    std::list<Entry> order_;
    std::unordered_map<int,std::list<Entry>::iterator> index_;
public:
    explicit TransactionalLru(std::size_t capacity) : capacity_(capacity) {}
    TransactionalLru(const TransactionalLru&) = delete;
    TransactionalLru& operator=(const TransactionalLru&) = delete;
    std::optional<int> get(int key) {
        auto it=index_.find(key);
        if (it==index_.end()) return std::nullopt;
        order_.splice(order_.begin(),order_,it->second);
        return it->second->second;
    }
    void put(int key,int value,bool injectFailure=false) {
        if (!capacity_) return;
        auto hit=index_.find(key);
        if (hit!=index_.end()) {
            hit->second->second=value;
            order_.splice(order_.begin(),order_,hit->second);
            return;
        }
        order_.emplace_front(key,value);
        try {
            if (injectFailure) throw std::runtime_error("injected index failure");
            index_.emplace(key,order_.begin());
        } catch (...) { order_.pop_front(); throw; }
        if (order_.size()>capacity_) {
            index_.erase(order_.back().first);
            order_.pop_back();
        }
    }
    std::vector<int> keys() const {
        std::vector<int> out;
        for (const auto& e:order_) out.push_back(e.first);
        return out;
    }
};
int main() {
    TransactionalLru cache(2);
    cache.put(1,10);
    cache.put(2,20);
    auto first=cache.get(1);
    assert(first==10);
    try {
        cache.put(3,30,true);
        assert(false);
    } catch (const std::runtime_error&) {}
    assert((cache.keys()==std::vector<int>{1,2}));
    cache.put(3,30);
    auto missing=cache.get(2);
    auto hit=cache.get(1);
    assert(!missing && hit==10);
    for (int key:cache.keys()) std::cout<<key<<' ';
    std::cout<<'\n';
}