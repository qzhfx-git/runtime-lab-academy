#include <sstream>
#include "fixture.hpp"
#include <optional>
#include <list>
#include <unordered_map>
#include "solutions/lru-cache.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="10 1";LruCache c(2);c.put(1,10);std::cout<<c.get(1).value_or(-1)<<" "<<c.size();break;}
case 1:{expected="101";LruCache c(2);c.put(1,10);c.put(2,20);c.get(1);c.put(3,30);std::cout<<c.get(1).has_value()<<c.get(2).has_value()<<c.get(3).has_value();break;}
case 2:{expected="7 0 2";LruCache c(2);c.put(1,1);c.put(2,2);c.put(1,7);c.put(3,3);std::cout<<c.get(1).value_or(-1)<<" "<<c.get(2).has_value()<<" "<<c.size();break;}
case 3:{expected="0 0";LruCache c(0);c.put(1,1);std::cout<<c.size()<<" "<<c.get(1).has_value();break;}
case 4:{expected="0 3";LruCache c(1);c.put(-1,9);c.get(50);c.put(2,3);std::cout<<c.get(-1).has_value()<<" "<<c.get(2).value_or(-1);break;}
case 5:{expected="1 0";LruCache c(8);bool ok=true;for(int i=0;i<500;++i){c.put(i,i*2);auto v=c.get(i);ok&=v&&*v==i*2;ok&=c.size()<=8;}std::cout<<ok<<" "<<std::is_copy_constructible_v<LruCache>;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
