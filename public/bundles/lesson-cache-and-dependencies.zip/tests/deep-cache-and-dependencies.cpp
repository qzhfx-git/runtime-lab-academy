#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-cache-and-dependencies.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 10";TransactionalLru x(2);x.put(1,10);x.put(2,20);x.get(1);x.put(3,30);std::cout<<x.get(2).has_value()<<" "<<x.get(1).value_or(-1);break;}
case 1:{expected="1 2 1";TransactionalLru x(2);x.put(1,10);x.put(2,20);bool threw=false;try{x.put(3,30,true);}catch(const std::runtime_error&){threw=true;}std::cout<<threw<<" ";for(int k:x.keys())std::cout<<k<<" ";break;}
case 2:{expected="0 1 8";TransactionalLru z(0);z.put(1,2);TransactionalLru x(1);x.put(1,2);x.put(1,8);std::cout<<z.keys().size()<<" "<<x.keys().size()<<" "<<x.get(1).value_or(-1);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
