enum class TaskState{succeeded=0,failed=1,skipped=2};
struct TaskResult{TaskState state=TaskState::skipped;int value=0;};
std::vector<TaskResult> run_graph(const std::vector<std::vector<std::size_t>>&,
const std::vector<std::function<int()>>& tasks){return std::vector<TaskResult>(tasks.size());}
