class TaskExecutor{public:explicit TaskExecutor(std::size_t){}std::future<int> submit(std::function<int()>){std::promise<int> p;p.set_value(0);return p.get_future();}void shutdown(){} };
