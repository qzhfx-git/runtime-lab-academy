# 任务完成之后，谁可以继续？

依赖、背压与关闭共同组成执行协议。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 为构建任务生成依赖顺序

实现 dependency_order(n,edges)，边 (u,v) 表示 u 必须在 v 之前完成。返回 optional<vector<int>>；有环时 nullopt。多个就绪任务总是选编号最小者。

- 输入端点均在 [0,n)，n 非负；重复边按独立边计数。
- 空图返回有值的空数组；自环必须识别。

### 具有失败传播的任务图

实现 run_graph，根据前置依赖顺序执行任务并记录终态。

- dependencies[i] 是节点 i 的前置编号；允许重复边。
- 数量不匹配或有环抛 invalid_argument，越界依赖抛 out_of_range；均不得调用任务。
- 仅全部前置成功才运行；异常记 failed，受影响下游记 skipped，独立分支继续。
- 结果按节点编号返回；成功保存值，失败和跳过值为零。此题顺序执行。

### 交付可关闭的任务执行器

实现 TaskExecutor(workers)：submit(std::function<int()>)->future<int>；shutdown() 排空已接受任务后 join；析构自动关闭。

- 至少一个工作线程，否则抛 invalid_argument。关闭后提交抛 runtime_error。
- 任务异常通过 future.get() 传回调用方；不能导致工作线程退出。
- shutdown 只由拥有者线程调用，不能由任务调用；调用 submit 的线程必须在析构前结束。

## 工程验收

- [ ] 跳过不运行回调
- [ ] 独立分支继续
- [ ] 非法图无回调
- [ ] 结果按节点编号保留
- [ ] 任务只入队一次
- [ ] 不在调度锁内执行用户代码

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
