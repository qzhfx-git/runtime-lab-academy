#include <sstream>
#include "fixture.hpp"
#include <mutex>
#include <condition_variable>
#include <deque>
#include <future>
#include <thread>
#include <atomic>
#include <latch>
#include "solutions/task-executor.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="42";TaskExecutor e(2);auto f=e.submit([]{return 42;});std::cout<<f.get();break;}
case 1:{expected="1 9";TaskExecutor e(1);auto a=e.submit([]()->int{throw std::logic_error("boom");});bool caught=false;try{a.get();}catch(const std::logic_error&){caught=true;}auto b=e.submit([]{return 9;});std::cout<<caught<<" "<<b.get();break;}
case 2:{expected="150";std::atomic<int> n{0};{TaskExecutor e(3);for(int i=0;i<150;++i)e.submit([&]{++n;return 0;});}std::cout<<n.load();break;}
case 3:{expected="1";TaskExecutor e(1);e.shutdown();e.shutdown();try{e.submit([]{return 1;});std::cout<<0;}catch(const std::runtime_error&){std::cout<<1;}break;}
case 4:{expected="3";TaskExecutor e(2);std::latch both(2);auto a=e.submit([&]{both.count_down();both.wait();return 1;});auto b=e.submit([&]{both.count_down();both.wait();return 2;});std::cout<<a.get()+b.get();break;}
case 5:{expected="1";try{TaskExecutor e(0);std::cout<<0;}catch(const std::invalid_argument&){std::cout<<1;}break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
