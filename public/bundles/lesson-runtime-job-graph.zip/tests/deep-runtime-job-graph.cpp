#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-runtime-job-graph.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="000 5";auto r=run_graph({{},{0},{0,1}},{[]{return 2;},[]{return 3;},[]{return 5;}});for(auto x:r)std::cout<<static_cast<int>(x.state);std::cout<<" "<<r[2].value;break;}
case 1:{expected="120 2 9";int n=0;auto r=run_graph({{},{0},{}},{[&]()->int{++n;throw std::runtime_error("x");},[&]{++n;return 1;},[&]{++n;return 9;}});for(auto x:r)std::cout<<static_cast<int>(x.state);std::cout<<" "<<n<<" "<<r[2].value;break;}
case 2:{expected="cycle 0";int n=0;try{run_graph({{1},{0}},{[&]{++n;return 1;},[&]{++n;return 2;}});}catch(const std::invalid_argument&){std::cout<<"cycle ";}std::cout<<n;break;}
case 3:{expected="bad 0 0 7";int n=0;try{run_graph({{9}},{[&]{++n;return 1;}});}catch(const std::out_of_range&){std::cout<<"bad ";}auto r=run_graph({{},{0,0}},{[]{return 1;},[]{return 7;}});std::cout<<n<<" "<<static_cast<int>(r[1].state)<<" "<<r[1].value;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
