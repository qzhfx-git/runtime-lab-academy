#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

enum class TaskState {succeeded=0,failed=1,skipped=2};
struct TaskResult {TaskState state=TaskState::skipped;int value=0;};
std::vector<TaskResult> run_graph(
    const std::vector<std::vector<std::size_t>>& dependencies,
    const std::vector<std::function<int()>>& tasks) {
    const auto n=tasks.size();
    if(dependencies.size()!=n) throw std::invalid_argument("size mismatch");
    std::vector<std::vector<std::size_t>> children(n);
    std::vector<std::size_t> indegree(n,0),order;
    for(std::size_t node=0;node<n;++node)
        for(auto parent:dependencies[node]) {
            if(parent>=n) throw std::out_of_range("dependency");
            children[parent].push_back(node);++indegree[node];
        }
    std::queue<std::size_t> ready;
    for(std::size_t i=0;i<n;++i) if(indegree[i]==0) ready.push(i);
    while(!ready.empty()) {
        auto node=ready.front();ready.pop();order.push_back(node);
        for(auto child:children[node]) if(--indegree[child]==0) ready.push(child);
    }
    if(order.size()!=n) throw std::invalid_argument("cycle");
    std::vector<TaskResult> results(n);
    for(auto node:order) {
        bool blocked=false;
        for(auto parent:dependencies[node])
            if(results[parent].state!=TaskState::succeeded) blocked=true;
        if(blocked) continue;
        try {results[node]={TaskState::succeeded,tasks[node]()};}
        catch(...) {results[node]={TaskState::failed,0};}
    }
    return results;
}
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    int called=0;
    std::vector<std::vector<std::size_t>> deps{{},{0},{0},{1,2},{}};
    std::vector<std::function<int()>> tasks{
        [&]{++called;return 1;},
        [&]()->int{++called;throw std::runtime_error("fail");},
        [&]{++called;return 3;},
        [&]{++called;return 4;},
        [&]{++called;return 9;}
    };
    auto result=run_graph(deps,tasks);
    check_example(called==4);
    check_example(result[1].state==TaskState::failed);
    check_example(result[3].state==TaskState::skipped);
    check_example(result[4].value==9);
    for(const auto& item:result) std::cout<<static_cast<int>(item.state);
    std::cout<<' '<<called<<'\n';
}
