template<class T>class WeakRegistry{public:void observe(const std::shared_ptr<T>&){}std::size_t alive()const{return 0;}std::size_t prune(){return 0;}template<class F>void visit(F&&){}};
