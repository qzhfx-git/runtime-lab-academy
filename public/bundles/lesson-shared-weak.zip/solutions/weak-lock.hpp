std::shared_ptr<Player> acquire(const std::weak_ptr<Player>& observer) {
    // TODO: 尝试取得已有的共享所有权
    return {};
}

