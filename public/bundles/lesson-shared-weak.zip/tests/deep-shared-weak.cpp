#include <sstream>
#include "fixture.hpp"
#include <memory>
#include <functional>
#include <vector>
#include "solutions/deep-shared-weak.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 1 0 1";WeakRegistry<int>r;auto a=std::make_shared<int>(3);r.observe(a);std::cout<<a.use_count()<<" "<<r.alive()<<" ";a.reset();std::cout<<r.alive()<<" "<<r.prune();break;}
case 1:{expected="1 1";WeakRegistry<int>r;auto a=std::make_shared<int>(1),b=std::make_shared<int>(2);r.observe(a);r.observe(b);int sum=0;r.visit([&](int&v){sum+=v;if(v==1)b.reset();});std::cout<<sum<<" "<<r.alive();break;}
case 2:{expected="1 4";WeakRegistry<int>r;auto a=std::make_shared<int>(1),b=std::make_shared<int>(2);r.observe(a);bool added=false;int sum=0;auto f=[&](int&v){sum+=v;if(!added){added=true;r.observe(b);}};r.visit(f);std::cout<<sum<<" ";r.visit(f);std::cout<<sum;break;}
case 3:{expected="2 1 2";WeakRegistry<int>r;auto a=std::make_shared<int>(4);r.observe({});r.observe(a);r.observe(a);int n=0;r.visit([&](int&){++n;});std::cout<<n<<" "<<r.prune()<<" "<<r.alive();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
