#include <sstream>
#include "fixture.hpp"

#include "solutions/weak-lock.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="80 2";auto p=std::make_shared<Player>(80);auto q=acquire(p);std::cout<<(q?q->hp:-1)<<' '<<p.use_count();break;}
case 1:{expected="0";std::weak_ptr<Player>w;std::cout<<bool(acquire(w));break;}
case 2:{expected="0 0";std::weak_ptr<Player>w;{auto p=std::make_shared<Player>();w=p;}auto q=acquire(w);std::cout<<bool(q)<<' '<<Player::alive;break;}
case 3:{expected="42 1 0";auto p=std::make_shared<Player>(42);auto q=acquire(p);p.reset();std::cout<<(q?q->hp:-1)<<' '<<Player::alive;q.reset();std::cout<<' '<<Player::alive;break;}
case 4:{expected="1 1";auto p=std::make_shared<Player>();auto q=acquire(p);std::cout<<(q&&!p.owner_before(q)&&!q.owner_before(p))<<' '<<(p.get()==q.get());break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
