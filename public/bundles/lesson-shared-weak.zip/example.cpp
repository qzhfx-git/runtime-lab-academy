#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <memory>
#include <functional>
#include <vector>
template<class T>class WeakRegistry {
    std::vector<std::weak_ptr<T>> entries_;
public:
    void observe(const std::shared_ptr<T>& value){entries_.push_back(value);}
    std::size_t alive()const{std::size_t n=0;for(const auto&w:entries_)if(!w.expired())++n;return n;}
    std::size_t prune(){const auto old=entries_.size();std::erase_if(entries_,[](const auto&w){return w.expired();});return old-entries_.size();}
    template<class F>void visit(F&&f){auto snapshot=entries_;for(const auto&w:snapshot)if(auto owner=w.lock())std::invoke(f,*owner);}
};
int main() {
WeakRegistry<int> registry;
auto first=std::make_shared<int>(1), second=std::make_shared<int>(2);
registry.observe(first);registry.observe(second);
assert(first.use_count()==1 && registry.alive()==2);
int sum=0;registry.visit([&](int&n){sum+=n;if(n==1)second.reset();});
assert(sum==1 && registry.alive()==1);
assert(registry.prune()==1);first.reset();
assert(registry.alive()==0);std::cout<<sum<<' '<<registry.prune();
}
