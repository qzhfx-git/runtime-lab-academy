# 拥有、观察，各司其职。

control block、weak_ptr 与所有权图。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 让观察者安全取得所有权

实现 acquire：从 weak_ptr<Player> 尝试取得共享所有权。对象已经销毁或观察者为空时，返回空 shared_ptr。不能从裸指针重新创建所有权。

- Player 由题目提供，成员 hp 为生命值，静态成员 alive 记录存活对象数。
- 返回值必须与已有的 shared_ptr 共享控制块，不得复制 Player。
- 测试器提供 main()，你只需补全函数。

### 不延长对象寿命的观察注册表

实现 WeakRegistry<T>，记录弱引用并按快照访问尚存活的对象。

- observe(shared_ptr<T>) 追加一个弱引用，允许重复和空指针。
- alive() 返回当前未过期记录数；prune() 删除过期记录并返回删除数。
- visit(f) 先复制弱引用列表，再依次 lock；成功时以 T& 调用同一个 f。
- visit 中新增观察从下一轮生效；回调异常直接传播；本课单线程。

## 工程验收

- [ ] 观察不增加强拥有计数
- [ ] lock 失败不访问对象
- [ ] 新增只影响下一轮
- [ ] 明确弱快照不会提前保活全部目标
- [ ] 全部综合测试通过
- [ ] 不把成员线程安全归因于引用计数

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
