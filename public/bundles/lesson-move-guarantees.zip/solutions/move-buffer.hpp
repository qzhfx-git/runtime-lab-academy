class Buffer {
    int* data_ = nullptr;
    std::size_t size_ = 0;
public:
    explicit Buffer(std::size_t n) : data_(n ? new int[n]{} : nullptr), size_(n) {}
    ~Buffer() { delete[] data_; }
    Buffer(const Buffer&) = delete;
    Buffer& operator=(const Buffer&) = delete;
    Buffer(Buffer&& other) noexcept {
        // TODO
    }
    Buffer& operator=(Buffer&& other) noexcept {
        // TODO
        return *this;
    }
    int* data() const { return data_; }
    std::size_t size() const { return size_; }
};

