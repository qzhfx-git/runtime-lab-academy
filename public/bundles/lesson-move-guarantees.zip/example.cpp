#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <functional>
#include <memory>
#include <algorithm>
#include <utility>
class IntBuffer {
    std::unique_ptr<int[]> data_;
    std::size_t size_=0;
public:
    explicit IntBuffer(const std::vector<int>& values):data_(values.empty()?nullptr:std::make_unique<int[]>(values.size())),size_(values.size()){if(size_)std::copy(values.begin(),values.end(),data_.get());}
    IntBuffer(const IntBuffer&)=delete;
    IntBuffer&operator=(const IntBuffer&)=delete;
    IntBuffer(IntBuffer&&o)noexcept:data_(std::move(o.data_)),size_(std::exchange(o.size_,0)){}
    IntBuffer&operator=(IntBuffer&&o)noexcept{if(this!=&o){data_=std::move(o.data_);size_=std::exchange(o.size_,0);}return *this;}
    std::size_t size()const noexcept{return size_;}
    int&at(std::size_t i){if(i>=size_)throw std::out_of_range("index");return data_[i];}
    const int&at(std::size_t i)const{if(i>=size_)throw std::out_of_range("index");return data_[i];}
    template<class F>void transform_strong(F&&f){
        auto next=size_?std::make_unique<int[]>(size_):nullptr;
        for(std::size_t i=0;i<size_;++i)next[i]=std::invoke(f,data_[i]);
        data_.swap(next);
    }
};
int main() {
IntBuffer input({1,2,3});
try{input.transform_strong([](int n){if(n==2)throw std::runtime_error("stop");return n*10;});}catch(const std::runtime_error&){}
assert(input.at(0)==1 && input.at(2)==3);
IntBuffer owner(std::move(input));assert(input.size()==0);
owner.transform_strong([](int n){return n+1;});owner=std::move(owner);
assert(owner.at(0)==2 && owner.at(2)==4);
std::cout<<input.size()<<' '<<owner.at(0)<<' '<<owner.at(2);
}
