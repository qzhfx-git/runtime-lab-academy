#include <sstream>
#include "fixture.hpp"
inline int liveArrays = 0;
void* operator new[](std::size_t n) { void* p=std::malloc(n?n:1); if(!p)throw std::bad_alloc(); ++liveArrays; return p; }
void operator delete[](void* p) noexcept { if(p){--liveArrays;std::free(p);} }
void operator delete[](void* p,std::size_t) noexcept { operator delete[](p); }

#include "solutions/move-buffer.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 3 42 0 1";Buffer a(3);a.data()[0]=42;auto raw=a.data();Buffer b(std::move(a));std::cout<<(b.data()==raw)<<' '<<b.size()<<' '<<(b.data()?b.data()[0]:-1)<<' '<<a.size()<<' '<<(a.data()==nullptr);break;}
case 1:{expected="1 2 9 0";Buffer a(2),b(5);a.data()[1]=9;auto raw=a.data();b=std::move(a);std::cout<<(b.data()==raw)<<' '<<b.size()<<' '<<(b.data()?b.data()[1]:-1)<<' '<<a.size();break;}
case 2:{expected="1 2";Buffer a(2);auto p=a.data();a=std::move(a);std::cout<<(a.data()==p)<<' '<<a.size();break;}
case 3:{expected="1 0 0";Buffer a(0),b(4);b=std::move(a);std::cout<<(b.data()==nullptr)<<' '<<b.size()<<' '<<a.size();break;}
case 4:{expected="1 1 0";std::cout<<std::is_nothrow_move_constructible_v<Buffer><<' '<<std::is_nothrow_move_assignable_v<Buffer><<' '<<std::is_copy_constructible_v<Buffer>;break;}
case 5:{expected="0";{Buffer a(2),b(5); b=std::move(a);}std::cout<<liveArrays;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
