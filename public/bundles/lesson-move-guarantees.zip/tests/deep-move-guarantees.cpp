#include <sstream>
#include "fixture.hpp"
#include <functional>
#include <memory>
#include <algorithm>
#include <utility>
#include "solutions/deep-move-guarantees.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 2 2";IntBuffer a({1,2}),b({9});b=std::move(a);std::cout<<a.size()<<" "<<b.size()<<" "<<b.at(1);break;}
case 1:{expected="3 2 0";IntBuffer a({3,4});a=std::move(a);const auto&c=a;std::cout<<c.at(0)<<" "<<c.size()<<" "<<std::is_copy_constructible_v<IntBuffer>;break;}
case 2:{expected="1 2 4";IntBuffer a({1,2,3});try{a.transform_strong([](int n){if(n==2)throw std::runtime_error("fail");return n*10;});}catch(const std::runtime_error&){}std::cout<<a.at(0)<<" "<<a.at(1)<<" ";a.transform_strong([](int n){return n+1;});std::cout<<a.at(2);break;}
case 3:{expected="0 1";IntBuffer a({});int calls=0;a.transform_strong([&](int n){++calls;return n;});bool caught=false;try{a.at(0);}catch(const std::out_of_range&){caught=true;}std::cout<<calls<<" "<<caught;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
