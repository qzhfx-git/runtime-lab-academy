# 移动，转移的是责任。

Rule of Five、noexcept 与容器搬迁。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 为 Buffer 实现移动操作

补全 Buffer 的移动构造和移动赋值，转移已有数组的所有权。移动后源对象为空；自移动保持原内容。

- 移动操作不得分配新数组，data() 地址跟随所有权转移。
- 禁止复制，移动必须 noexcept。
- 移动赋值需要释放目标旧数组。

### 可移动缓冲区与事务变换

实现 IntBuffer(vector<int>)，支持移动、带边界的 at 和 transform_strong(f)。

- 禁止复制；移动后源 size() 为零；自移动保持内容不变。
- at(index) 越界抛 out_of_range；提供 const 与非 const 重载。
- transform_strong 在独立缓冲区计算，任一次 f 抛出时原缓冲区不变。
- f 接收 int 返回 int；不得通过别名修改原缓冲区，外部副作用不在回滚范围内。

## 工程验收

- [ ] 源长度清零
- [ ] 目的旧资源正确释放
- [ ] 失败后所有原元素不变
- [ ] 成功后结果一次发布
- [ ] 全部综合测试通过
- [ ] 解释额外数组的成本

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
