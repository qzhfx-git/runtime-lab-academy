# 视图越轻，寿命越要清楚。

span 传递范围，ranges 描述计算，容器承担结果所有权。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 从借用视图生成独立结果

实现 even_squares(span<const int>)：按原顺序返回所有偶数的平方。输入绝对值不超过 1000。

- 结果拥有自己的存储，不借用输入。
- 不得排序或修改输入；负偶数同样被选中。

### 从借用输入生成拥有型报告

实现 build_report(span<const BorrowedRow>,threshold)，选出 score>=threshold 的行，保序复制名字并将分数乘二。

- 输出拥有每个名字的字符串，输入随后销毁或修改不影响结果。
- 只对入选行执行乘法；若入选分数乘二超出 int 范围，抛 overflow_error。
- 不得修改输入；允许空名字、内含零字节名字与空输入。
- 函数返回完整 vector；异常时没有部分结果发布。输入的所有借用在调用期间必须有效。

## 工程验收

- [ ] 不修改输入
- [ ] 结果独立存储
- [ ] 销毁输入后仍能读报告
- [ ] 按长度复制字符
- [ ] 全部综合测试通过
- [ ] 不发布半份结果

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
