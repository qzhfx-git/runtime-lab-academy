std::vector<int> even_squares(std::span<const int> input) { (void)input; return {}; }
