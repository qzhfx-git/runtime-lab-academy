std::vector<OwnedRow> build_report(std::span<const BorrowedRow>,int){return {};}
