#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <span>
#include <ranges>
#include <string_view>
#include <string>
struct BorrowedRow{std::string_view name;int score;};
struct OwnedRow{std::string name;int score;};
#include <limits>
#include <stdexcept>
std::vector<OwnedRow> build_report(std::span<const BorrowedRow> input,int threshold){
    std::vector<OwnedRow> result;
    auto selected=input|std::views::filter([threshold](const auto&r){return r.score>=threshold;});
    for(const auto&row:selected){
        if(row.score>std::numeric_limits<int>::max()/2 || row.score<std::numeric_limits<int>::min()/2)
            throw std::overflow_error("score");
        result.push_back({std::string(row.name),row.score*2});
    }
    return result;
}
int main() {
std::vector<OwnedRow> report;
{std::string name="worker";std::array<BorrowedRow,2> rows{{{name,3},{"ignored",-1}}};
 report=build_report(rows,0);name[0]='X';assert(report[0].name=="worker");}
assert(report.size()==1 && report[0].score==6);
bool rejected=false;std::array<BorrowedRow,1> huge{{{"huge",std::numeric_limits<int>::max()}}};
try{build_report(huge,0);}catch(const std::overflow_error&){rejected=true;}
assert(rejected);std::cout<<report[0].name<<' '<<report[0].score<<' '<<rejected;
}
