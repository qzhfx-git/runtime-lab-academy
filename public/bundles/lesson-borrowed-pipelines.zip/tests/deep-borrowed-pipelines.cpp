#include <sstream>
#include "fixture.hpp"
#include <span>
#include <ranges>
#include <string_view>
#include <string>
struct BorrowedRow{std::string_view name;int score;};
struct OwnedRow{std::string name;int score;};
#include <limits>
#include <stdexcept>
#include "solutions/deep-borrowed-pipelines.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="A:6 C:8";std::array<BorrowedRow,3>a{{{"A",3},{"B",1},{"C",4}}};for(auto&r:build_report(a,3))std::cout<<r.name<<":"<<r.score<<" ";break;}
case 1:{expected="job 4";std::string name="job";std::array<BorrowedRow,1>a{{{name,2}}};auto out=build_report(a,0);name[0]='X';if(out.empty())std::cout<<"empty";else std::cout<<out[0].name<<" "<<out[0].score;break;}
case 2:{expected="1 1";std::array<BorrowedRow,2>a{{{"low",std::numeric_limits<int>::min()},{"ok",1}}};std::cout<<build_report(a,0).size()<<" ";bool caught=false;try{build_report(a,std::numeric_limits<int>::min());}catch(const std::overflow_error&){caught=true;}std::cout<<caught;break;}
case 3:{expected="3 0";std::string s{'a',char(0),'b'};std::array<BorrowedRow,1>a{{{s,0}}};auto out=build_report(a,0);std::cout<<(out.empty()?0:out[0].name.size())<<" "<<build_report({},0).size();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
