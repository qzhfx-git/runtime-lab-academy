#include <sstream>
#include "fixture.hpp"
#include <span>
#include <ranges>
#include "solutions/range-pipeline.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="4 16";std::vector<int> a{1,2,3,4};for(int v:even_squares(a))std::cout<<v<<" ";break;}
case 1:{expected="16 0 4";std::vector<int> a{-4,-3,0,2};for(int v:even_squares(a))std::cout<<v<<" ";break;}
case 2:{expected="0 0";std::cout<<even_squares({}).size()<<" "<<even_squares(std::array{1,3,5}).size();break;}
case 3:{expected="4 16 4";std::vector<int>a{2,4};auto b=even_squares(a);a[0]=99;std::cout<<b[0]<<" "<<b[1]<<" "<<a[1];break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
