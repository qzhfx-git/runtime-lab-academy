#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <vector>
#include <utility>
auto make_history(std::vector<int> seed){
    return [history=std::move(seed)](int value) mutable {
        history.push_back(value);
        return history;
    };
}
int main() {
std::vector<int> seed{1};auto log=make_history(seed);seed[0]=99;
auto first=log(2);assert((first==std::vector<int>{1,2}));first[0]=88;
auto branch=log;auto a=log(3);auto b=branch(7);
assert((a==std::vector<int>{1,2,3}));assert((b==std::vector<int>{1,2,7}));
std::cout<<a.front()<<' '<<a.back()<<' '<<b.back();
}
