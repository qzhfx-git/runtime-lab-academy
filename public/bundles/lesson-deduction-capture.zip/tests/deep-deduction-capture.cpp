#include <sstream>
#include "fixture.hpp"
#include <vector>
#include <utility>
#include "solutions/deep-deduction-capture.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 2";std::vector<int>seed{1};auto log=make_history(seed);seed[0]=9;auto a=log(2);for(int n:a)std::cout<<n<<" ";break;}
case 1:{expected="3 4";auto log=make_history({});auto first=log(3);if(!first.empty())first[0]=99;auto second=log(4);if(second.size()<2)std::cout<<"short";else std::cout<<second[0]<<" "<<second[1];break;}
case 2:{expected="3 8 3 3";auto a=make_history({1});a(2);auto b=a;auto x=a(3);auto y=b(8);std::cout<<(x.empty()?0:x.back())<<" "<<(y.empty()?0:y.back())<<" "<<x.size()<<" "<<y.size();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
