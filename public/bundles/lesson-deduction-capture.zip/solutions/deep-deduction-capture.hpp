auto make_history(std::vector<int> seed){(void)seed;return [](int){return std::vector<int>{};};}
