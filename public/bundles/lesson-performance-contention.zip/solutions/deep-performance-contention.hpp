class ShardedCounters {
public:
    explicit ShardedCounters(std::size_t){}
    bool add(std::size_t,std::uint64_t){return false;}
    std::optional<std::uint64_t> total()const{return 0;}
};
