#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-performance-contention.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="11 16";ShardedCounters c(2);std::cout<<c.add(0,7)<<c.add(1,9)<<" ";auto t=c.total();std::cout<<(t?*t:0);break;}
case 1:{expected="010 1";ShardedCounters c(1);std::cout<<c.add(9,1)<<c.add(0,std::numeric_limits<std::uint64_t>::max())<<c.add(0,1)<<" "<<(c.total()==std::optional<std::uint64_t>{std::numeric_limits<std::uint64_t>::max()});break;}
case 2:{expected="0 0";ShardedCounters c(2);c.add(0,std::numeric_limits<std::uint64_t>::max());c.add(1,1);ShardedCounters empty(0);std::cout<<c.total().has_value()<<" "<<empty.total().value_or(9);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
