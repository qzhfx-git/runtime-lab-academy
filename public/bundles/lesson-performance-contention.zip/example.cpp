#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class ShardedCounters {
    struct alignas(64) Shard { std::uint64_t value=0; };
    std::vector<Shard> shards_;
public:
    explicit ShardedCounters(std::size_t n):shards_(n){}
    bool add(std::size_t index,std::uint64_t delta) {
        if(index>=shards_.size()) return false;
        auto& value=shards_[index].value;
        if(delta>std::numeric_limits<std::uint64_t>::max()-value) return false;
        value+=delta; return true;
    }
    std::optional<std::uint64_t> total() const {
        std::uint64_t sum=0;
        for(const auto& shard:shards_) {
            if(shard.value>std::numeric_limits<std::uint64_t>::max()-sum)
                return std::nullopt;
            sum+=shard.value;
        }
        return sum;
    }
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    ShardedCounters counters(2);
    std::jthread a([&]{for(int i=0;i<1000;++i) check_example(counters.add(0,1));});
    std::jthread b([&]{for(int i=0;i<1000;++i) check_example(counters.add(1,2));});
    a.join(); b.join();
    auto total=counters.total();
    check_example(total && *total==3000);
    std::cout<<*total<<'\n';
}
