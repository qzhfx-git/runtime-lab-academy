#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-atomic-publication.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 7 9";OneShot b;std::array<int,3> o{7,8,9};std::cout<<b.try_read(o)<<" "<<o[0]<<" "<<o[2];break;}
case 1:{expected="1 3 -2 10";OneShot b;b.publish({3,-2,10});std::array<int,3> o{};bool ok=b.try_read(o);std::cout<<ok<<" "<<o[0]<<" "<<o[1]<<" "<<o[2];break;}
case 2:{expected="1 1 1 0";OneShot b;b.publish({0,0,0});std::array<int,3>a{1,2,3},c{4,5,6};std::cout<<b.try_read(a)<<" "<<b.try_read(c)<<" "<<(a==c)<<" "<<a[2];break;}
case 3:{expected="1 66";OneShot b;std::jthread p([&]{b.publish({11,22,33});});p.join();std::array<int,3>a{};std::cout<<b.try_read(a)<<" "<<a[0]+a[1]+a[2];break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
