#include <sstream>
#include "fixture.hpp"
#include <atomic>
#include <thread>
#include "solutions/release-publish.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="42";SinglePublication p;p.publish(42);std::cout<<p.wait();break;}
case 1:{expected="-7";SinglePublication p;int observed=0;std::thread reader([&]{observed=p.wait();});std::thread writer([&]{p.publish(-7);});writer.join();reader.join();std::cout<<observed;break;}
case 2:{expected="1";bool ok=true;for(int i=1;i<=30;++i){SinglePublication p;int v=0;std::thread t([&]{v=p.wait();});p.publish(i);t.join();ok&=v==i;}std::cout<<ok;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
