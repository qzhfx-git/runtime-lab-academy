#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class OneShot {
    std::array<int, 3> data_{};
    std::atomic<bool> ready_{false};
public:
    void publish(std::array<int, 3> value) {
        data_ = value;
        ready_.store(true, std::memory_order_release);
    }
    bool try_read(std::array<int, 3>& output) const {
        if (!ready_.load(std::memory_order_acquire)) return false;
        output = data_;
        return true;
    }
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    OneShot box;
    std::array<int, 3> output{9, 9, 9};
    check_example(!box.try_read(output));
    check_example((output == std::array<int, 3>{9, 9, 9}));
    box.publish({10, 20, 30});
    check_example(box.try_read(output));
    check_example((output == std::array<int, 3>{10, 20, 30}));
    std::cout << output[0] << ' ' << output[1] << ' ' << output[2] << '\n';
}
