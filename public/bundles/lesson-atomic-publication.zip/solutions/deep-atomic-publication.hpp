class OneShot {
public:
    void publish(std::array<int, 3>) {}
    bool try_read(std::array<int, 3>&) const { return false; }
};
