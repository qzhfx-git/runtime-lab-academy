class SinglePublication{public:void publish(int){}int wait(){return 0;} };
