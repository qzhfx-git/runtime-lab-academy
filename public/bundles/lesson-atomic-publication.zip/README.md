# 先发布数据，再发布可见性。

用 happens-before 解释跨线程交接。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 发布数据，也发布可见性

实现 SinglePublication：一个发布者调用 publish(int) 一次，一个读取者调用 wait() 返回该值。对象构造在两个线程启动之前。

- 用 atomic<bool> 表达就绪状态，数据为普通 int。
- publish 在写入数据后 release；wait 在 acquire 观察 true 后读数据。等待时可 yield。

### 一次性快照信箱

实现 OneShot，一次发布三个整数，发布后可以重复读取。

- 一个生产者，publish 最多调用一次，发布后不再写载荷。
- try_read 失败保持输出，成功返回完整数组。
- 销毁不与访问并发；内存序另需人工论证。

## 工程验收

- [ ] 失败读取不修改输出
- [ ] 逐边解释写入如何先行发生于读取
- [ ] 字段完整保留
- [ ] 区分尚未发布和全零结果
- [ ] 所有读取期间对象存活
- [ ] 明确动态检查不能证明的关系

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
