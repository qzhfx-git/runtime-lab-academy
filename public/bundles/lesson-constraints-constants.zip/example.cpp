#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <concepts>
#include <span>
#include <type_traits>
#include <utility>
template<class C>concept TransactionalIntSink=
    std::copy_constructible<C> && std::is_nothrow_swappable_v<C> &&
    requires(C&value,const C&read,std::size_t count,int element){
        {read.size()}->std::same_as<std::size_t>;
        {value.reserve(count)}->std::same_as<void>;
        {value.push_back(element)}->std::same_as<void>;
    };
template<TransactionalIntSink C>
bool append_checked(C&destination,std::span<const int>input,std::size_t maximum){
    const auto current=destination.size();
    if(current>maximum || input.size()>maximum-current)return false;
    C next=destination;
    next.reserve(current+input.size());
    for(int element:input)next.push_back(element);
    using std::swap;swap(destination,next);
    return true;
}
int main() {
static_assert(TransactionalIntSink<std::vector<int>>);
constexpr auto fits=[](std::size_t used,std::size_t extra,std::size_t limit){return used<=limit && extra<=limit-used;};
static_assert(fits(2,3,5));static_assert(!fits(2,4,5));
struct Sink{std::vector<int>v;std::size_t size()const{return v.size();}void reserve(std::size_t n){v.reserve(n);}void push_back(int n){if(n<0)throw std::runtime_error("reject");v.push_back(n);}};
static_assert(TransactionalIntSink<Sink>);Sink sink{{1}};
try{append_checked(sink,std::array{2,-1},5);}catch(const std::runtime_error&){}
assert((sink.v==std::vector<int>{1}));assert(append_checked(sink,std::array{2,3},3));
assert(!append_checked(sink,std::array{4},3));
std::cout<<sink.v.size()<<' '<<sink.v.front()<<' '<<sink.v.back();
}
