# 把要求放在错误发生之前。

Concepts 约束接口，constexpr 检查可计算的规则。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 把泛型要求写进接口

定义概念 Reservable<T>：T& 上的 reserve(size_t) 表达式必须返回 void，const T& 上的 size() 必须可转换为 size_t。

- 必须同时检查两个表达式和返回类型约束。
- 不要求 size() 标记 noexcept，也不要求类型可默认构造。

### 带强保证的泛型批量追加

定义 TransactionalIntSink<C> 概念及 append_checked(C&,span<const int>,maximum)，把符合契约的容器作为事务目标。

- 概念要求 C 可复制构造、可无抛 swap；C& 上 reserve(size_t)、push_back(int) 返回 void，const C& 上 size() 精确返回 size_t。
- 若现有大小大于 maximum 或追加后超限，返回 false 且不改变目标。
- 合法请求先复制目标并修改副本，成功后交换提交；分配或 push_back 异常传播且目标不变。
- 概念不要求默认构造；实现语义要求这些操作确实满足容器含义。

## 工程验收

- [ ] 无默认构造类型可接受
- [ ] 返回类型错误被拒绝
- [ ] 拒绝不修改目标
- [ ] 加法前已经证明范围
- [ ] 全部测试通过
- [ ] 解释无抛交换为何是要求

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
