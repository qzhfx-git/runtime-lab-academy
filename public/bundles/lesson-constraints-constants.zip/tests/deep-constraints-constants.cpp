#include <sstream>
#include "fixture.hpp"
#include <concepts>
#include <span>
#include <type_traits>
#include <utility>
#include "solutions/deep-constraints-constants.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="100";struct Missing{void reserve(std::size_t);};struct Wrong{std::size_t size()const;int reserve(std::size_t);void push_back(int);};std::cout<<TransactionalIntSink<std::vector<int>><<TransactionalIntSink<Missing><<TransactionalIntSink<Wrong>;break;}
case 1:{expected="0 1 1 3";std::vector<int>a{1};std::array<int,2>b{2,3};std::cout<<append_checked(a,b,2)<<" "<<a.size()<<" "<<append_checked(a,b,3)<<" "<<a.back();break;}
case 2:{expected="1 1";struct C{std::vector<int>v;std::size_t size()const{return v.size();}void reserve(std::size_t n){v.reserve(n);}void push_back(int n){if(n<0)throw std::runtime_error("negative");v.push_back(n);}};C c{{1}};std::array<int,2>input{2,-1};try{append_checked(c,input,9);}catch(const std::runtime_error&){}std::cout<<c.v.size()<<" "<<c.v[0];break;}
case 3:{expected="1 1 5";struct C{std::vector<int>v;C()=delete;explicit C(int n):v{n}{}std::size_t size()const{return v.size();}void reserve(std::size_t n){v.reserve(n);}void push_back(int n){v.push_back(n);}};C c(4);std::cout<<TransactionalIntSink<C><<" "<<append_checked(c,std::array{5},2)<<" "<<c.v.back();break;}
case 4:{expected="0 2";std::vector<int>a{1,2};std::cout<<append_checked(a,{},1)<<" "<<a.size();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
