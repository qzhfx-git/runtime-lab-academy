#include <sstream>
#include "fixture.hpp"
#include <concepts>
#include "solutions/reservable-concept.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 1";std::cout<<Reservable<std::vector<int>><<" "<<Reservable<std::string>;break;}
case 1:{expected="0 0 0";struct A{void reserve(std::size_t){}};struct B{int reserve(std::size_t){return 0;}std::size_t size()const{return 0;}};std::cout<<Reservable<A><<" "<<Reservable<B><<" "<<Reservable<int>;break;}
case 2:{expected="1";struct A{A()=delete;void reserve(std::size_t);unsigned size()const;};std::cout<<Reservable<A>;break;}
case 3:{expected="0";struct A{void reserve(std::size_t);std::size_t size();};std::cout<<Reservable<A>;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
