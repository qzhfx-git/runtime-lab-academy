template<class C>concept TransactionalIntSink=false;
template<class C>bool append_checked(C&,std::span<const int>,std::size_t){return false;}
