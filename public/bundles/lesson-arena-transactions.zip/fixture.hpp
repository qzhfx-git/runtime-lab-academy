#pragma once
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <limits>
#include <memory>
#include <new>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
struct Player {
    inline static int alive = 0;
    int hp;
    explicit Player(int h=100) : hp(h) { ++alive; }
    ~Player() { --alive; }
    Player(const Player&) = delete;
    Player& operator=(const Player&) = delete;
};
struct Widget {
    inline static int alive = 0;
    int value;
    explicit Widget(int v) : value(v) { ++alive; }
    ~Widget() { --alive; }
};
