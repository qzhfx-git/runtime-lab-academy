#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class CheckpointArena {
    alignas(64) std::array<std::byte,128> storage_{};
    std::size_t capacity_, used_=0;
    std::uint64_t generation_=1;
public:
    struct Mark { std::size_t offset; std::uint64_t generation; };
    explicit CheckpointArena(std::size_t capacity) : capacity_(capacity) {
        if (capacity>storage_.size()) throw std::invalid_argument("capacity");
    }
    CheckpointArena(const CheckpointArena&)=delete;
    CheckpointArena& operator=(const CheckpointArena&)=delete;
    void* allocate(std::size_t bytes,std::size_t alignment) {
        if (!bytes || !alignment || alignment>64 || (alignment&(alignment-1))) return nullptr;
        void* candidate=storage_.data()+used_;
        std::size_t space=capacity_-used_;
        if (!std::align(alignment,bytes,candidate,space)) return nullptr;
        used_=static_cast<std::byte*>(candidate)-storage_.data()+bytes;
        return candidate;
    }
    Mark mark() const noexcept { return {used_,generation_}; }
    bool rewind(Mark m) noexcept {
        if (m.generation!=generation_ || m.offset>used_) return false;
        used_=m.offset; return true;
    }
    void reset() {
        if (generation_==std::numeric_limits<std::uint64_t>::max())
            throw std::overflow_error("generation exhausted");
        used_=0; ++generation_;
    }
    std::size_t used() const noexcept { return used_; }
};
int main() {
    CheckpointArena arena(64);
    auto before=arena.mark();
    void* raw=arena.allocate(sizeof(int),alignof(int));
    assert(raw);
    auto* value=std::construct_at(static_cast<int*>(raw),42);
    assert(*value==42);
    auto used=arena.used();
    void* failed=arena.allocate(1000,8);
    assert(!failed && arena.used()==used);
    std::destroy_at(value);
    bool rewound=arena.rewind(before);
    assert(rewound && arena.used()==0);
    arena.reset();
    bool stale=arena.rewind(before);
    assert(!stale);
    std::cout<<"arena transaction ok\n";
}