# 批量分配，也需要事务边界。

对齐、溢出、检查点与 Arena 回滚。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### TinyRuntime 前置实验：线性 Arena

实现 Arena::allocate 和 reset，在固定 256 字节存储里按顺序分配。容量不足返回 nullptr，并保持原分配位置。

- bytes > 0；alignment 为非零 2 的幂，不超过 alignof(max_align_t)。
- 成功分配的区域对齐且不重叠。
- reset 只回收空间，调用方负责此前对象的析构。

### 有检查点的对齐分配器 · 综合实现

完成 CheckpointArena，再设计非平凡对象析构记录扩展。

- 实现 CheckpointArena(capacity)、allocate(bytes,alignment)、mark()、rewind(Mark)、reset()、used()；Mark 含 offset、generation。
- capacity 为 0 至 128，超过抛 invalid_argument；bytes=0 或非法/超过64的对齐返回 nullptr；失败不改 used。
- 只传本 Arena 产生且未被回退越过的检查点；reset 使旧 Mark 失效。调用方先销毁对象再回退。

## 工程验收

- [ ] 地址满足对齐
- [ ] 申请不重叠
- [ ] 非法请求不推进
- [ ] 旧周期检查点失败
- [ ] 综合测试通过
- [ ] 明确检查点有效期

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
