#include <sstream>
#include "fixture.hpp"

#include "solutions/arena.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 8 1";Arena a;auto p=a.allocate(8,8);std::cout<<(p!=nullptr)<<' '<<a.used()<<' '<<(reinterpret_cast<std::uintptr_t>(p)%8==0);break;}
case 1:{expected="1 16 8";Arena a;auto p=a.allocate(1,1);auto q=a.allocate(8,8);std::cout<<(p&&q)<<' '<<a.used()<<' '<<(p&&q?static_cast<std::byte*>(q)-static_cast<std::byte*>(p):-1);break;}
case 2:{expected="1 0 256";Arena a;auto p=a.allocate(256,1);auto q=a.allocate(1,1);std::cout<<bool(p)<<' '<<bool(q)<<' '<<a.used();break;}
case 3:{expected="0 1 4";Arena a;auto p=a.allocate(300,1);auto q=a.allocate(4,4);std::cout<<bool(p)<<' '<<bool(q)<<' '<<a.used();break;}
case 4:{expected="1 16";Arena a;auto p=a.allocate(16,8);a.reset();auto q=a.allocate(16,8);std::cout<<(p&&p==q)<<' '<<a.used();break;}
case 5:{expected="0 249";Arena a;a.allocate(249,1);auto p=a.allocate(8,8);std::cout<<bool(p)<<' '<<a.used();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
