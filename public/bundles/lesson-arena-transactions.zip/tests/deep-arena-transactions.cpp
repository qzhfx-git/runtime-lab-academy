#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-arena-transactions.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1 1 1";CheckpointArena a(128);void*p=a.allocate(3,1);void*q=a.allocate(8,32);std::cout<<(p!=nullptr)<<" "<<(q!=nullptr&&reinterpret_cast<std::uintptr_t>(q)%32==0)<<" "<<(a.used()==40);break;}
case 1:{expected="1 1 1";CheckpointArena a(16);a.allocate(4,4);auto n=a.used();std::cout<<(a.allocate(1000,8)==nullptr)<<" "<<(a.allocate(1,3)==nullptr)<<" "<<(a.used()==n);break;}
case 2:{expected="1 0 0";CheckpointArena a(32);auto m=a.mark();a.allocate(8,8);std::cout<<a.rewind(m)<<" "<<a.used()<<" ";a.reset();std::cout<<a.rewind(m);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
