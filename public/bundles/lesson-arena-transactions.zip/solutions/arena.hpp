class Arena {
    alignas(std::max_align_t) std::byte storage_[256];
    std::size_t used_ = 0;
public:
    void* allocate(std::size_t bytes, std::size_t alignment) {
        // TODO: 失败不得推进 used_
        return nullptr;
    }
    void reset() { /* TODO */ }
    std::size_t used() const { return used_; }
};

