#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <functional>
#include <type_traits>
#include <utility>
template<class F>class OnceTask {
    static_assert(std::is_nothrow_move_constructible_v<F>);
    static_assert(std::is_invocable_v<F&&>);
    F function_;
    bool active_=true;
public:
    explicit OnceTask(F f)noexcept:function_(std::move(f)){}
    OnceTask(const OnceTask&)=delete;
    OnceTask&operator=(const OnceTask&)=delete;
    OnceTask(OnceTask&&other)noexcept:function_(std::move(other.function_)),active_(std::exchange(other.active_,false)){}
    bool run(){if(!std::exchange(active_,false))return false;std::invoke(std::move(function_));return true;}
};
template<class F>auto make_once_task(F&& f){
    return OnceTask<std::decay_t<F>>(std::forward<F>(f));
}
int main() {
struct Action {
 std::unique_ptr<int> payload;int*sum;
 Action(int n,int&s):payload(std::make_unique<int>(n)),sum(&s){}
 Action(Action&&)noexcept=default;Action(const Action&)=delete;
 void operator()()&&{*sum+=*payload;payload.reset();}
 void operator()() & = delete;
};
int sum=0;auto source=make_once_task(Action{9,sum});auto target=std::move(source);
assert(!source.run());assert(target.run());assert(!target.run());assert(sum==9);
int attempts=0;auto failure=make_once_task([&]{++attempts;throw std::runtime_error("failed");});
try{failure.run();}catch(const std::runtime_error&){}
assert(!failure.run()&&attempts==1);
std::cout<<sum<<' '<<attempts<<' '<<std::is_copy_constructible_v<decltype(target)>;
}
