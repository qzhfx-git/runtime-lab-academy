#include <sstream>
#include "fixture.hpp"
#include <functional>
#include <type_traits>
#include <utility>
#include "solutions/deep-forwarding-identity.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 10 0";int n=0;auto t=make_once_task([p=std::make_unique<int>(7),&n]{n+=*p;});bool first=t.run(),second=t.run();std::cout<<n<<" "<<first<<second<<" "<<std::is_copy_constructible_v<decltype(t)>;break;}
case 1:{expected="1 1";struct F{int*p;void operator()()&&{++*p;}void operator()() & = delete;};int n=0;auto t=make_once_task(F{&n});std::cout<<t.run()<<" "<<n;break;}
case 2:{expected="010 1";int n=0;auto a=make_once_task([&]{++n;});auto b=std::move(a);std::cout<<a.run()<<b.run()<<b.run()<<" "<<n;break;}
case 3:{expected="0 1";int n=0;auto t=make_once_task([&]{++n;throw std::runtime_error("fail");});try{t.run();}catch(const std::runtime_error&){}std::cout<<t.run()<<" "<<n;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
