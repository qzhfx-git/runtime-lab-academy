#include <sstream>
#include "fixture.hpp"
#include <functional>
#include "solutions/generic-repeat.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="8";int v=1;repeat_apply(3,[](int&n){n*=2;},v);std::cout<<v;break;}
case 1:{expected="6 3";struct F{int count=0;F()=default;F(const F&)=delete;void operator()(int&v){v+=++count;}};F f;int v=0;repeat_apply(3,f,v);std::cout<<v<<" "<<f.count;break;}
case 2:{expected="4";int v=4;auto f=[](int&){throw 1;};repeat_apply(0,f,v);repeat_apply(-2,f,v);std::cout<<v;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
