template<class F>class OnceTask{public:explicit OnceTask(F){}OnceTask(const OnceTask&)=delete;OnceTask(OnceTask&&)noexcept{}bool run(){return false;}};
template<class F>auto make_once_task(F&&f){return OnceTask<std::decay_t<F>>(std::forward<F>(f));}
