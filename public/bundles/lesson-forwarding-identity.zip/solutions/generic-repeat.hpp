template<class F,class T> void repeat_apply(int n,F&& f,T& value){(void)n;(void)f;(void)value;}
