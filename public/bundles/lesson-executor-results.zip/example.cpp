#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class BoundedExecutor {
    std::mutex mutex_;
    std::condition_variable ready_;
    std::deque<std::packaged_task<int()>> jobs_;
    std::vector<std::jthread> workers_;
    std::size_t capacity_;
    bool closed_=false;
    void work() {
        for (;;) {
            std::packaged_task<int()> task;
            {
                std::unique_lock lock(mutex_);
                ready_.wait(lock,[&]{return closed_ || !jobs_.empty();});
                if (jobs_.empty()) return;
                task=std::move(jobs_.front()); jobs_.pop_front();
            }
            task();
        }
    }
public:
    BoundedExecutor(std::size_t workers,std::size_t capacity):capacity_(capacity) {
        if (!workers || !capacity) throw std::invalid_argument("zero workers/capacity");
        try { for (std::size_t i=0;i<workers;++i) workers_.emplace_back([this]{work();}); }
        catch (...) { stop(); throw; }
    }
    std::future<int> submit(std::function<int()> fn) {
        std::packaged_task<int()> task(std::move(fn));
        auto future=task.get_future();
        {
            std::lock_guard lock(mutex_);
            if (closed_ || jobs_.size()>=capacity_) throw std::runtime_error("rejected");
            jobs_.push_back(std::move(task));
        }
        ready_.notify_one(); return future;
    }
    // 单一拥有者调用；不能由本池工作线程调用，不能与另一次 stop 并发。
    void stop() {
        { std::lock_guard lock(mutex_); closed_=true; }
        ready_.notify_all();
        workers_.clear(); // 析构 jthread 并 join；队列排空之后线程才退出
    }
    ~BoundedExecutor() { stop(); }
};
int main() {
    BoundedExecutor pool(2,8);
    auto first=pool.submit([] { return 21; });
    auto failed=pool.submit([]()->int { throw std::runtime_error("boom"); });
    auto last=pool.submit([] { return 34; });
    pool.stop();
    int a=first.get(), c=last.get();
    assert(a==21 && c==34);
    bool threw=false;
    try { failed.get(); }
    catch (const std::runtime_error&) { threw=true; }
    assert(threw);
    try {
        pool.submit([] { return 0; });
        assert(false);
    } catch (const std::runtime_error&) {}
    std::cout<<"results=55 exception=1 closed=1\n";
}