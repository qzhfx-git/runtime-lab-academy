# 提交任务，也要交代结果与结束。

future、异常传播、线程池与背压边界。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 交付可关闭的任务执行器

实现 TaskExecutor(workers)：submit(std::function<int()>)->future<int>；shutdown() 排空已接受任务后 join；析构自动关闭。

- 至少一个工作线程，否则抛 invalid_argument。关闭后提交抛 runtime_error。
- 任务异常通过 future.get() 传回调用方；不能导致工作线程退出。
- shutdown 只由拥有者线程调用，不能由任务调用；调用 submit 的线程必须在析构前结束。

### 带结果通道的有界执行器 · 综合实现

完成 BoundedExecutor 并论证外部 stop 与任务依赖边界。

- 实现 BoundedExecutor(workers,capacity)、submit(function<int()>)->future<int>、stop()；析构调用 stop。
- 零线程或零容量抛 invalid_argument；关闭或排队数量达到容量时 submit 抛 runtime_error；已接受任务排空，异常由 future 传播。
- stop 只由单一外部拥有者调用，不与另一 stop 并发，不由工作线程调用；任务最终返回，不在池内阻塞等待同池子任务。

## 工程验收

- [ ] 值准确返回
- [ ] 业务异常不终止其他任务
- [ ] 满载立即拒绝
- [ ] 已接受任务被排空
- [ ] 综合测试通过
- [ ] 注明 stop 所有者约束

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
