#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-executor-results.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 1";BoundedExecutor p(2,8);auto a=p.submit([]{return 7;});auto b=p.submit([]()->int{throw std::runtime_error("x");});p.stop();bool caught=false;try{b.get();}catch(const std::runtime_error&){caught=true;}std::cout<<a.get()<<" "<<caught;break;}
case 1:{expected="1 3";BoundedExecutor p(1,1);std::promise<void> entered,release;auto gate=release.get_future().share();auto a=p.submit([&]{entered.set_value();gate.wait();return 1;});entered.get_future().wait();auto b=p.submit([]{return 2;});bool rejected=false;try{p.submit([]{return 3;});}catch(const std::runtime_error&){rejected=true;}release.set_value();p.stop();std::cout<<rejected<<" "<<a.get()+b.get();break;}
case 2:{expected="10 1";BoundedExecutor p(1,8);std::vector<std::future<int>> f;for(int i=1;i<=4;++i)f.push_back(p.submit([i]{return i;}));p.stop();p.stop();int sum=0;for(auto&x:f)sum+=x.get();bool rejected=false;try{p.submit([]{return 5;});}catch(const std::runtime_error&){rejected=true;}std::cout<<sum<<" "<<rejected;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
