class BoundedExecutor {public: BoundedExecutor(std::size_t,std::size_t){} std::future<int> submit(std::function<int()>){throw std::runtime_error("TODO: implement submit");} void stop(){}};
