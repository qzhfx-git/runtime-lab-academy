#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
struct PricePolicy {
    virtual ~PricePolicy()=default;
    virtual int quote(int cents) const=0;
};
class StandardPrice final : public PricePolicy {
public:
    int quote(int cents) const override {
        if (cents<0) throw std::invalid_argument("negative price");
        return cents;
    }
};
class MemberPrice final : public PricePolicy {
public:
    int quote(int cents) const override {
        if (cents<0) throw std::invalid_argument("negative price");
        return static_cast<int>(static_cast<std::int64_t>(cents)*9/10);
    }
};
std::unique_ptr<PricePolicy> make_policy(const std::string& name) {
    if (name=="standard") return std::make_unique<StandardPrice>();
    if (name=="member") return std::make_unique<MemberPrice>();
    throw std::invalid_argument("unknown policy");
}
int main(){auto normal=make_policy("standard");auto member=make_policy("member");assert(normal->quote(101)==101);assert(member->quote(101)==90);assert(member->quote(std::numeric_limits<int>::max())>=0);bool bad=false;try{make_policy("unknown");}catch(const std::invalid_argument&){bad=true;}assert(bad);std::cout<<normal->quote(101)<<' '<<member->quote(101)<<'\n';}