#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
struct PricePolicy {
    virtual ~PricePolicy()=default;
    virtual int quote(int cents) const=0;
};

#include "solutions/deep-strategy-factory.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="101 90 0";auto a=make_policy("standard"),b=make_policy("member");std::cout<<a->quote(101)<<" "<<b->quote(101)<<" "<<b->quote(0);break;}
case 1:{expected="11";bool a=false,b=false;try{make_policy("bad");}catch(const std::invalid_argument&){a=true;}try{make_policy("member")->quote(-1);}catch(const std::invalid_argument&){b=true;}std::cout<<a<<b;break;}
case 2:{expected="1 7";auto p=make_policy("member");int n=std::numeric_limits<int>::max();std::cout<<(p->quote(n)==static_cast<int>(static_cast<std::int64_t>(n)*9/10))<<" "<<make_policy("standard")->quote(7);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
