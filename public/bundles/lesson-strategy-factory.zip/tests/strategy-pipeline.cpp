#include <sstream>
#include "fixture.hpp"
#include <functional>
#include "solutions/strategy-pipeline.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="[xA]";TextPipeline p;p.add([](std::string s){return s+"A";});p.add([](std::string s){return "["+s+"]";});std::cout<<p.run("x");break;}
case 1:{expected="ready ready";TextPipeline p;std::string s="ready";std::cout<<p.run(s)<<" "<<s;break;}
case 2:{expected="1";TextPipeline p;p.add([](std::string)->std::string{throw std::runtime_error("bad");});try{p.run("x");std::cout<<0;}catch(const std::runtime_error&){std::cout<<1;}break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
