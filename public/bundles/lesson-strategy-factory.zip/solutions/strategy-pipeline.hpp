class TextPipeline{public:void add(std::function<std::string(std::string)>){ }std::string run(std::string input)const{return input;} };
