std::unique_ptr<PricePolicy> make_policy(const std::string&){throw std::runtime_error("TODO: implement factory");}
