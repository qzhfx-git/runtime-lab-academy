# 把变化装进组合，而不是分支深处。

Strategy 定义可替换行为，Factory 负责合法创建。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 组合可替换的处理策略

实现 TextPipeline：add(function<string(string)>) 添加步骤，run(string) 按注册顺序执行；空管线返回原文。

- 管线拥有回调；用户输入按值传入，不修改调用方字符串。
- 异常向调用方传播，不悄悄返回成功。

### 可替换的金额策略工厂 · 综合实现

完成 make_policy，再设计优惠、税费和运费组合顺序。

- 题目提供 PricePolicy，含虚析构及 virtual int quote(int) const=0；实现 make_policy(string)。
- standard 返回原价；member 返回非负金额的九折向下取整到分；负金额抛 invalid_argument；未知名称也抛 invalid_argument。
- 全部 int 非负输入都必须避免中间溢出；返回 unique_ptr<PricePolicy>。

## 工程验收

- [ ] 负数统一拒绝
- [ ] 正常结果准确
- [ ] 未知名明确失败
- [ ] 中间乘法不溢出
- [ ] 综合测试通过
- [ ] 标明策略版本与线程契约

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
