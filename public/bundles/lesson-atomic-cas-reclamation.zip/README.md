# CAS 成功，不等于结构安全。

分开思考更新、ABA 与内存回收。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 原子额度池

实现 CreditPool 的 acquire、release、available。

- 容量固定，可用量处于零到容量。
- 不足或归还超容量返回 false 且状态不变；零操作成功。
- 不跟踪申请者身份，不发布普通载荷，不实现等待和节点回收。

## 工程验收

- [ ] 无下溢
- [ ] 无超容量
- [ ] 失败不改变额度
- [ ] 危险算术发生在验证后
- [ ] 不会重复归还
- [ ] 不宣称数字 CAS 解决指针回收

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
