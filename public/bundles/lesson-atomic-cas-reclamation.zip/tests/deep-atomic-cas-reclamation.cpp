#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

#include "solutions/deep-atomic-cas-reclamation.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="10 2 1 0";CreditPool p(5);std::cout<<p.acquire(3)<<p.acquire(3)<<" "<<p.available()<<" "<<p.acquire(2)<<" "<<p.available();break;}
case 1:{expected="1 4 0 4";CreditPool p(5);p.acquire(4);std::cout<<p.release(3)<<" "<<p.available()<<" "<<p.release(std::numeric_limits<unsigned>::max())<<" "<<p.available();break;}
case 2:{expected="1100 0";CreditPool p(0);std::cout<<p.acquire(0)<<p.release(0)<<p.acquire(1)<<p.release(1)<<" "<<p.available();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
