class CreditPool {
    unsigned value_;
public:
    explicit CreditPool(unsigned c):value_(c){}
    bool acquire(unsigned){return false;}
    bool release(unsigned){return false;}
    unsigned available()const{return value_;}
};
