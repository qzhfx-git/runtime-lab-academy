#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <charconv>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <queue>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
#include <coroutine>
#include <exception>

class CreditPool {
    const unsigned capacity_;
    std::atomic<unsigned> available_;
public:
    explicit CreditPool(unsigned c) : capacity_(c), available_(c) {}
    bool acquire(unsigned amount) {
        auto old = available_.load(std::memory_order_relaxed);
        while (old >= amount)
            if (available_.compare_exchange_weak(old, old-amount,
                std::memory_order_relaxed, std::memory_order_relaxed)) return true;
        return false;
    }
    bool release(unsigned amount) {
        auto old = available_.load(std::memory_order_relaxed);
        while (amount <= capacity_-old)
            if (available_.compare_exchange_weak(old, old+amount,
                std::memory_order_relaxed, std::memory_order_relaxed)) return true;
        return false;
    }
    unsigned available() const { return available_.load(std::memory_order_relaxed); }
};
void check_example(bool condition) {
    assert(condition);
    if (!condition) throw std::logic_error("example check failed");
}
int main() {
    CreditPool pool(5);
    check_example(pool.acquire(3));
    check_example(!pool.acquire(3));
    check_example(pool.release(2));
    check_example(!pool.release(2));
    check_example(pool.acquire(0));
    check_example(pool.available()==4);
    std::cout<<pool.available()<<'\n';
}
