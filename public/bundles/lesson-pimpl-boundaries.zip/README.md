# 把实现变化，留在边界里面。

Pimpl、ABI 与可维护 API 的取舍。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 把清理动作绑定到作用域

实现 ScopeExit：构造接收 std::function<void()>；析构时执行一次；dismiss() 放弃执行；支持移动构造，禁止复制。回调约定不抛异常。

- 移动后旧对象不得再执行回调。
- 异常离开作用域也必须清理；不要求移动赋值。

### 具有值语义的 Pimpl 文档 · 综合实现

完成 Document 并设计私有实现升级验证。

- 实现 Document 默认/文本构造、深复制、复制赋值、noexcept移动、text()、revision()、replace(string)。
- 默认文本空、版本0；成功 replace 版本加1；文本超过64字节抛 length_error 且不修改；文本构造等价默认后replace。
- 移动后源查询空文本与0，可再次replace；非线程安全。使用 unique_ptr<Impl> 且在完整类型处定义相关成员。

## 工程验收

- [ ] 客户端可单独编译
- [ ] 拥有资源正确释放
- [ ] 副本互不影响
- [ ] 移动后源可查询和重用
- [ ] 综合测试通过
- [ ] 区分三种兼容性

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
