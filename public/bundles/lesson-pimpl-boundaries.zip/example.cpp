#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class Document {
    struct Impl;
    std::unique_ptr<Impl> impl_;
public:
    Document();
    explicit Document(std::string text);
    ~Document();
    Document(const Document&);
    Document& operator=(const Document&);
    Document(Document&&) noexcept;
    Document& operator=(Document&&) noexcept;
    std::string text() const;
    std::size_t revision() const noexcept;
    void replace(std::string text);
};
struct Document::Impl { std::string text; std::size_t revision=0; };
Document::Document():impl_(std::make_unique<Impl>()) {}
Document::Document(std::string text):Document() { replace(std::move(text)); }
Document::~Document()=default;
Document::Document(Document&&) noexcept=default;
Document& Document::operator=(Document&&) noexcept=default;
Document::Document(const Document& other):impl_(other.impl_ ? std::make_unique<Impl>(*other.impl_) : nullptr) {}
Document& Document::operator=(const Document& other) {
    if (this!=&other) { Document copy(other); impl_.swap(copy.impl_); }
    return *this;
}
std::string Document::text() const { return impl_ ? impl_->text : std::string{}; }
std::size_t Document::revision() const noexcept { return impl_ ? impl_->revision : 0; }
void Document::replace(std::string text) {
    if (text.size()>64) throw std::length_error("document limit");
    if (revision()==std::numeric_limits<std::size_t>::max()) throw std::overflow_error("revision");
    if (!impl_) impl_=std::make_unique<Impl>();
    impl_->text.swap(text); ++impl_->revision;
}
int main(){Document a("alpha");Document b=a;b.replace("beta");assert(a.text()=="alpha"&&b.text()=="beta");Document moved(std::move(b));assert(b.text().empty()&&b.revision()==0);b.replace("reused");assert(b.text()=="reused"&&b.revision()==1);auto old=a.revision();try{a.replace(std::string(65,'x'));assert(false);}catch(const std::length_error&){}assert(a.text()=="alpha"&&a.revision()==old);assert(moved.text()=="beta");std::cout<<"alpha beta reused\n";}