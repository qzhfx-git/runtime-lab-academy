#include <sstream>
#include "fixture.hpp"
#include <functional>
#include "solutions/scope-exit.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="1";int n=0;{ScopeExit g([&]{++n;});}std::cout<<n;break;}
case 1:{expected="1";int n=0;try{ScopeExit g([&]{++n;});throw 1;}catch(int){}std::cout<<n;break;}
case 2:{expected="1 0";int n=0;{ScopeExit a([&]{++n;});ScopeExit b(std::move(a));}{ScopeExit c([&]{n+=100;});c.dismiss();}std::cout<<n<<" "<<std::is_copy_constructible_v<ScopeExit>;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
