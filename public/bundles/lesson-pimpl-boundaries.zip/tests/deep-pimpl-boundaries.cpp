#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-pimpl-boundaries.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="abc 122";Document a("a");Document b=a;b.replace("b");Document c;c=a;c.replace("c");std::cout<<a.text()<<b.text()<<c.text()<<" "<<a.revision()<<b.revision()<<c.revision();break;}
case 1:{expected="10 xy 1";Document a("x");Document b(std::move(a));std::cout<<a.text().empty()<<a.revision()<<" ";a.replace("y");std::cout<<b.text()<<a.text()<<" "<<a.revision();break;}
case 2:{expected="1 stable 1";Document a("stable");bool rejected=false;try{a.replace(std::string(65,'x'));}catch(const std::length_error&){rejected=true;}a=a;std::cout<<rejected<<" "<<a.text()<<" "<<a.revision();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
