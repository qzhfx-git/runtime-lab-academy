class Document {public: Document()=default; explicit Document(std::string){} std::string text() const{return {};} std::size_t revision() const noexcept{return 0;} void replace(std::string){}};
