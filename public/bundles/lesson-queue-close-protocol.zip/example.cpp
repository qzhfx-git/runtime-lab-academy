#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class CloseQueue {
    std::size_t capacity_;
    std::deque<int> queue_;
    std::mutex mutex_;
    std::condition_variable readable_,writable_;
    bool closed_=false;
public:
    explicit CloseQueue(std::size_t capacity):capacity_(capacity) {
        if (!capacity) throw std::invalid_argument("zero capacity");
    }
    bool push(int value) {
        std::unique_lock lock(mutex_);
        writable_.wait(lock,[&]{return closed_ || queue_.size()<capacity_;});
        if (closed_) return false;
        queue_.push_back(value);
        lock.unlock(); readable_.notify_one(); return true;
    }
    std::optional<int> pop() {
        std::unique_lock lock(mutex_);
        readable_.wait(lock,[&]{return closed_ || !queue_.empty();});
        if (queue_.empty()) return std::nullopt;
        int value=queue_.front(); queue_.pop_front();
        lock.unlock(); writable_.notify_one(); return value;
    }
    void close() {
        { std::lock_guard lock(mutex_); closed_=true; }
        readable_.notify_all(); writable_.notify_all();
    }
};
int main() {
    CloseQueue queue(2);
    int sum=0;
    std::jthread consumer([&] { while (auto x=queue.pop()) sum+=*x; });
    std::jthread producer([&] {
        for (int i=1;i<=5;++i) {
            bool accepted=queue.push(i);
            assert(accepted);
        }
        queue.close();
    });
    producer.join();
    consumer.join();
    assert(sum==15);
    bool accepted=queue.push(9);
    auto ended=queue.pop();
    assert(!accepted && !ended);
    queue.close();
    std::cout<<"sum=15 closed\n";
}