class BlockingQueue {public:explicit BlockingQueue(std::size_t){}bool push(int){return false;}std::optional<int> pop(){return {};}void close(){} };
