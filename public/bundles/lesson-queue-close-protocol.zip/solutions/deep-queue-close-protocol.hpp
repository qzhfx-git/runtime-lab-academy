class CloseQueue {public: explicit CloseQueue(std::size_t){} bool push(int){return false;} std::optional<int> pop(){return {};} void close(){}};
