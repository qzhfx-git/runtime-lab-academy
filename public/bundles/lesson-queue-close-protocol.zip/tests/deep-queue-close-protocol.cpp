#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-queue-close-protocol.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="20 210";CloseQueue q(2);int total=0,count=0;std::jthread c([&]{while(auto x=q.pop()){total+=*x;++count;}});for(int i=1;i<=20;++i)q.push(i);q.close();c.join();std::cout<<count<<" "<<total;break;}
case 1:{expected="0 4 5 0";CloseQueue q(2);q.push(4);q.push(5);q.close();q.close();auto a=q.pop(),b=q.pop();std::cout<<q.push(6)<<" "<<a.value_or(-1)<<" "<<b.value_or(-1)<<" "<<q.pop().has_value();break;}
case 2:{expected="0 7 0";CloseQueue q(1);q.push(7);std::promise<void> entered;bool accepted=true;std::jthread p([&]{entered.set_value();accepted=q.push(8);});entered.get_future().wait();q.close();p.join();auto value=q.pop();std::cout<<accepted<<" "<<value.value_or(-1)<<" "<<q.pop().has_value();break;}
case 3:{expected="0";CloseQueue q(1);bool has=true;std::jthread c([&]{has=q.pop().has_value();});q.close();c.join();std::cout<<has;break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
