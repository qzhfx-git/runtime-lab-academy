#include <sstream>
#include "fixture.hpp"
#include <deque>
#include <mutex>
#include <condition_variable>
#include <optional>
#include <thread>
#include <latch>
#include <set>
#include "solutions/blocking-queue.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7 8 0 0";BlockingQueue q(2);q.push(7);q.push(8);q.close();std::cout<<q.pop().value_or(-1)<<" "<<q.pop().value_or(-1)<<" "<<q.pop().has_value()<<" "<<q.push(9);break;}
case 1:{expected="500 125250";BlockingQueue q(1);std::thread p([&]{for(int i=1;i<=500;++i)q.push(i);q.close();});int sum=0,n=0;while(auto v=q.pop()){sum+=*v;++n;}p.join();std::cout<<n<<" "<<sum;break;}
case 2:{expected="0 1";BlockingQueue q(1);q.push(1);bool accepted=true;std::latch started(1);std::thread p([&]{started.count_down();accepted=q.push(2);});started.wait();q.close();p.join();std::cout<<accepted<<" "<<q.pop().value_or(-1);break;}
case 3:{expected="300 300";BlockingQueue q(8);std::vector<std::thread>p;for(int k=0;k<3;++k)p.emplace_back([&,k]{for(int i=1;i<=100;++i)q.push(k*100+i);});std::thread closer([&]{for(auto&t:p)t.join();q.close();});std::set<int> seen;int count=0;while(auto v=q.pop()){seen.insert(*v);++count;}closer.join();std::cout<<count<<" "<<seen.size();break;}
case 4:{expected="1";try{BlockingQueue q(0);std::cout<<0;}catch(const std::invalid_argument&){std::cout<<1;}break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
