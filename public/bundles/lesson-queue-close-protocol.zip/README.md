# 等待的不是通知，是一个条件。

虚假唤醒、有界队列与可结束的生产消费。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 让有界队列正确等待和关闭

实现 BlockingQueue(capacity)：push(int)->bool 队满等待，pop()->optional<int> 队空等待，close() 唤醒全部等待者。容量 0 抛 invalid_argument。

- close 后 push 返回 false；pop 排空已有元素后返回 nullopt。
- close 幂等；禁止忙等或依赖 sleep；对象销毁前调用方已退出。

### 可关闭的有界生产消费队列 · 综合实现

完成 CloseQueue 并记录资源结束协议。

- 实现 CloseQueue(capacity)、阻塞 push(int)->bool、阻塞 pop()->optional<int>、幂等 close()。
- 容量零抛 invalid_argument；满时 push 等待，关闭后返回 false；pop 排空已接受数据后返回 nullopt。
- push/pop/close 支持并发；对象析构前调用者必须停止调用并 join 所有使用线程。

## 工程验收

- [ ] FIFO 正确
- [ ] 满时不超容量
- [ ] 生产消费者均可退出
- [ ] 关闭后不新增
- [ ] 综合测试通过
- [ ] 不用 sleep 证明同步

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
