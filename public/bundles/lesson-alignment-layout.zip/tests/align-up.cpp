#include <sstream>
#include "fixture.hpp"

#include "solutions/align-up.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="16";std::cout<<align_up(13,8);break;}
case 1:{expected="16 0";std::cout<<align_up(16,8)<<' '<<align_up(0,64);break;}
case 2:{expected="4 4 4 4 8";for(std::size_t i=1;i<=5;++i)std::cout<<align_up(i,4)<<' ';break;}
case 3:{expected="1";auto m=std::numeric_limits<std::size_t>::max();std::cout<<(align_up(m,1)==m);break;}
case 4:{expected="overflow";try{align_up(std::numeric_limits<std::size_t>::max(),8);std::cout<<"missed";}catch(const std::overflow_error&){std::cout<<"overflow";}break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
