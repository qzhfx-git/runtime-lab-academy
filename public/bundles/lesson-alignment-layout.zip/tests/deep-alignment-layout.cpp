#include <sstream>
#include "fixture.hpp"
#include <optional>
#include <limits>
#include "solutions/deep-alignment-layout.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="0 8 10";LayoutPlanner p(16);std::cout<<p.allocate(3,1).value_or(999)<<" "<<p.allocate(2,8).value_or(999)<<" "<<p.used();break;}
case 1:{expected="000 3";LayoutPlanner p(10);p.allocate(3,1);std::cout<<p.allocate(9,8).has_value()<<p.allocate(1,3).has_value()<<p.allocate(1,0).has_value()<<" "<<p.used();break;}
case 2:{expected="8 8 0";LayoutPlanner p(8);p.allocate(3,1);std::cout<<p.allocate(0,8).value_or(999)<<" "<<p.used()<<" ";p.reset();std::cout<<p.allocate(8,1).value_or(999);break;}
case 3:{expected="0 1";auto m=std::numeric_limits<std::size_t>::max();LayoutPlanner p(m);p.allocate(m-1,1);std::cout<<p.allocate(0,8).has_value()<<" "<<(p.used()==m-1);break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
