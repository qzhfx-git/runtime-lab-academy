#include <algorithm>
#include <array>
#include <cassert>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <optional>
#include <limits>
class LayoutPlanner {
    std::size_t capacity_, used_=0;
public:
    explicit LayoutPlanner(std::size_t capacity):capacity_(capacity){}
    std::optional<std::size_t> allocate(std::size_t bytes,std::size_t alignment){
        if(alignment==0 || (alignment&(alignment-1))!=0)return {};
        const auto mask=alignment-1;
        if(used_>std::numeric_limits<std::size_t>::max()-mask)return {};
        const auto offset=(used_+mask)&~mask;
        if(offset>capacity_ || bytes>capacity_-offset)return {};
        used_=offset+bytes;
        return offset;
    }
    std::size_t used()const noexcept{return used_;}
    void reset()noexcept{used_=0;}
};
int main() {
LayoutPlanner plan(16);
auto first=plan.allocate(3,1); auto second=plan.allocate(2,8);
assert(first==0 && second==8 && plan.used()==10);
auto denied=plan.allocate(7,8); assert(!denied && plan.used()==10);
assert(plan.allocate(1,1)==10);
std::cout<<*first<<' '<<*second<<' '<<plan.used();
}
