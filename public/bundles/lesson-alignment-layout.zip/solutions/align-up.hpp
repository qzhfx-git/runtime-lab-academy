std::size_t align_up(std::size_t offset, std::size_t alignment) {
    // TODO: 对齐，并检查溢出
    return offset;
}

