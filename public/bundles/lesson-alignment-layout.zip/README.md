# 让每个对象，落在合法的位置。

理解 alignment、padding 与布局契约。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 计算下一处合法对齐位置

实现 align_up，把 offset 向上取整到 alignment 的倍数。alignment 保证为非零的 2 的幂。若结果超出 size_t 范围，抛出 overflow_error。

- 已经对齐的 offset 保持不变。
- 不允许静默回绕到错误的偏移。

### 有边界的布局规划器

实现 LayoutPlanner(capacity)：allocate(bytes,alignment) 返回可用偏移或 nullopt，不真正分配对象存储。

- alignment 必须是非零二次幂；无效请求不改变 used()。
- 检查向上对齐和区间结尾的整数溢出。
- 零字节请求合法，可能因对齐消耗 padding；reset() 将游标归零。
- 这是相对零偏移的布局计算器，实际存储基地址仍须满足最大对齐。

## 工程验收

- [ ] 结果不小于原值
- [ ] 每个结果是八的倍数
- [ ] 失败后 used 不变
- [ ] 零容量不发生除零或回绕
- [ ] 最大整数附近的请求安全失败
- [ ] 不把偏移规划描述成对象构造

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
