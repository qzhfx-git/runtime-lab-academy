#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>
class AccountPair {
    mutable std::mutex firstMutex_,secondMutex_;
    int first_,second_;
public:
    AccountPair(int first,int second):first_(first),second_(second) {
        if (first<0 || second<0) throw std::invalid_argument("negative balance");
    }
    bool transfer(int from,int to,int amount) {
        if (from<0 || from>1 || to<0 || to>1 || amount<0) return false;
        std::scoped_lock guard(firstMutex_,secondMutex_);
        int& src=from==0 ? first_:second_;
        int& dst=to==0 ? first_:second_;
        if (src<amount) return false;
        if (from==to) return true;
        if (dst>std::numeric_limits<int>::max()-amount) return false;
        src-=amount; dst+=amount; return true;
    }
    std::pair<int,int> snapshot() const {
        std::scoped_lock guard(firstMutex_,secondMutex_);
        return {first_,second_};
    }
};
int main() {
    AccountPair pair(1000,1000);
    std::jthread first([&] {
        for (int i=0;i<100;++i) {
            bool ok=pair.transfer(0,1,1);
            assert(ok);
        }
    });
    std::jthread second([&] {
        for (int i=0;i<100;++i) {
            bool ok=pair.transfer(1,0,1);
            assert(ok);
        }
    });
    first.join();
    second.join();
    assert((pair.snapshot()==std::pair<int,int>{1000,1000}));
    bool overdraft=pair.transfer(0,1,2000);
    bool self=pair.transfer(0,0,10);
    assert(!overdraft && self);
    std::cout<<"1000 1000\n";
}