#include <sstream>
#include "fixture.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <memory_resource>
#include <mutex>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "solutions/deep-locks-and-thread-lifetime.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="100 7 23";AccountPair p(10,20);std::cout<<p.transfer(0,1,3)<<p.transfer(0,1,100)<<p.transfer(0,1,-1)<<" ";auto[a,b]=p.snapshot();std::cout<<a<<" "<<b;break;}
case 1:{expected="1000 1000";AccountPair p(1000,1000);std::jthread a([&]{for(int i=0;i<300;++i)p.transfer(0,1,1);});std::jthread b([&]{for(int i=0;i<300;++i)p.transfer(1,0,1);});a.join();b.join();auto[x,y]=p.snapshot();std::cout<<x<<" "<<y;break;}
case 2:{expected="010 8 1";AccountPair p(8,std::numeric_limits<int>::max());std::cout<<p.transfer(0,1,1)<<p.transfer(0,0,8)<<p.transfer(2,0,1)<<" ";auto[a,b]=p.snapshot();std::cout<<a<<" "<<(b==std::numeric_limits<int>::max());break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
