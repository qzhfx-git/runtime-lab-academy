#include <sstream>
#include "fixture.hpp"
#include <mutex>
#include <thread>
#include "solutions/locked-counter.hpp"
int main(int argc,char**argv){ if(argc!=2)return 2;std::ostringstream captured;auto* original=std::cout.rdbuf(captured.rdbuf());std::string expected;try{switch(std::stoi(argv[1])){
case 0:{expected="7";ConcurrentCounter c;c.add(9);c.add(-2);std::cout<<c.value();break;}
case 1:{expected="16000";ConcurrentCounter c;std::vector<std::thread>t;for(int k=0;k<4;++k)t.emplace_back([&]{for(int i=0;i<4000;++i)c.add(1);});for(auto&x:t)x.join();std::cout<<c.value();break;}
case 2:{expected="1 2000";ConcurrentCounter c;std::thread t([&]{for(int i=0;i<2000;++i)c.add(1);});bool ok=true;long long last=0;for(int i=0;i<2000;++i){auto v=c.value();ok&=v>=last;last=v;}t.join();std::cout<<ok<<" "<<c.value();break;}
default:std::cout.rdbuf(original);return 2;}}catch(const std::exception& e){std::cout.rdbuf(original);std::cerr<<e.what();return 3;}std::cout.rdbuf(original);auto actual=captured.str();while(!actual.empty()&&(actual.back()==' '||actual.back()=='\n'||actual.back()=='\r'||actual.back()=='\t'))actual.pop_back();if(actual!=expected){std::cerr<<"Expected: "<<expected<<"\nActual: "<<actual;return 1;}std::cout<<"PASS\n";return 0;}
