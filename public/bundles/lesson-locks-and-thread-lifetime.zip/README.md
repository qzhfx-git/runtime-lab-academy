# 锁保护不变量，线程也需要所有者。

mutex、锁顺序、join 与协作停止。

## 构建

需要 CMake 3.20+、C++20 编译器和可用构建工具。MSYS2 UCRT64 示例（已安装 Ninja 时）：

    cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=g++
    cmake --build build
    ctest --test-dir build --output-on-failure

初始代码刻意未完成，测试失败是预期行为；填写 solutions 中的实现。tests 为可检查的测试驱动，不包含参考实现。

## 练习

### 给共享状态定义同步边界

实现 ConcurrentCounter：add(long long) 和 value() const 必须可并发调用，初始值为 0。

- 所有访问同一个受保护的状态，不得使用 volatile 充当同步。
- 对象销毁前所有调用方已退出；数值不会溢出 long long。

### 有一致快照的账户转账 · 综合实现

完成 AccountPair 并提交线程寿命与同步证明。

- 实现 AccountPair(first,second)、transfer(from,to,amount)、snapshot()；账户编号0和1。
- 余额初始非负，否则抛 invalid_argument。非法编号、负金额、余额不足、目标溢出均返回false不修改；合法自转账不修改。
- transfer 和 snapshot 支持并发；snapshot 同时反映两个账户的一致状态。

## 工程验收

- [ ] 总额不变
- [ ] 拒绝不修改
- [ ] 联合锁协议一致
- [ ] 整数不溢出
- [ ] 综合测试通过
- [ ] 说明有限测试与 TSan 缺口

有限功能测试不证明复杂度、并发正确性或职业等级。线上本机评测有资源限制，直接运行下载的工程不附带这些限制；请审查自己编写的代码。
