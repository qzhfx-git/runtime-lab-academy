class AccountPair {public: AccountPair(int,int){} bool transfer(int,int,int){return false;} std::pair<int,int> snapshot() const{return {0,0};}};
