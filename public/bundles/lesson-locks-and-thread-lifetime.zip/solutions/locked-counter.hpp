class ConcurrentCounter {public:void add(long long){}long long value()const{return 0;} };
